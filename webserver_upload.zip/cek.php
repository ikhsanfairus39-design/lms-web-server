<?php header('Content-Type: text/html; charset=utf-8');
function ok($n,$v){echo '<p>'.($v?'✅':'❌').' '.htmlspecialchars($n).'</p>';}
echo '<body style="font-family:sans-serif;max-width:640px;margin:30px auto"><h3>Cek Server - Web Server LMS</h3>';
ok('PHP versi '.PHP_VERSION,version_compare(PHP_VERSION,'7.4','>='));
foreach(['pdo_mysql','mbstring','zlib'] as $x)ok("Ekstensi $x (wajib)",extension_loaded($x));
echo '<p>'.(extension_loaded('zip')?'✅':'ℹ️').' Ekstensi zip (opsional, aplikasi tidak membutuhkannya)</p>';
try{new PDO('mysql:host=localhost','root','');ok('Koneksi MySQL (user root, tanpa password)',true);}catch(Exception $e){ok('Koneksi MySQL gagal: '.$e->getMessage().' (pastikan MySQL Running di XAMPP)',false);}
ok('Folder aplikasi: '.__DIR__,is_file(__DIR__.'/index.php'));
ok('File database ada (sql/webserver.sql)',is_file(__DIR__.'/sql/webserver.sql'));
ok('Logo sertifikat ada',is_file(__DIR__.'/img/logo-smk-juwiring.jpg')&&is_file(__DIR__.'/img/logo-smk-bisa-hebat.jpg'));
echo '<p><a href="index.php">Buka aplikasi →</a></p>';

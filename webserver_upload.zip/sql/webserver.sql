CREATE DATABASE IF NOT EXISTS webserver CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE webserver;
DROP TABLE IF EXISTS lkpd_jawab,lkpd,jawaban,hasil,evaluasi_soal,evaluasi,soal,materi,users;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE,password CHAR(32),nama VARCHAR(100),role ENUM('guru','murid'),kelas VARCHAR(20) DEFAULT 'XI TKJ');
CREATE TABLE materi(id INT AUTO_INCREMENT PRIMARY KEY,judul VARCHAR(200),isi MEDIUMTEXT);
CREATE TABLE soal(id INT AUTO_INCREMENT PRIMARY KEY,pertanyaan TEXT,mapel VARCHAR(50) DEFAULT 'TKJ',a VARCHAR(255),b VARCHAR(255),c VARCHAR(255),d VARCHAR(255),kunci CHAR(1));
CREATE TABLE evaluasi(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(150),mapel VARCHAR(50),waktu INT DEFAULT 60,created TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE evaluasi_soal(evaluasi_id INT,soal_id INT,PRIMARY KEY(evaluasi_id,soal_id),FOREIGN KEY(evaluasi_id) REFERENCES evaluasi(id) ON DELETE CASCADE,FOREIGN KEY(soal_id) REFERENCES soal(id) ON DELETE CASCADE);
CREATE TABLE hasil(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,evaluasi_id INT,nilai INT,benar INT,total INT,tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(evaluasi_id) REFERENCES evaluasi(id) ON DELETE CASCADE);
CREATE TABLE jawaban(id INT AUTO_INCREMENT PRIMARY KEY,hasil_id INT,soal_id INT,jawab CHAR(1),FOREIGN KEY(hasil_id) REFERENCES hasil(id) ON DELETE CASCADE);
INSERT INTO users(username,password,nama,role) VALUES('guru',MD5('1234'),'Guru TKJ','guru');
INSERT INTO materi(judul,isi) VALUES('Web Server: Pengertian, Fungsi, Kelebihan dan Kekurangan','<h3>1. Pengertian Web Server</h3><p>Web server adalah perangkat lunak (dan komputer yang menjalankannya) yang menerima permintaan HTTP/HTTPS dari client (browser), lalu mengirimkan kembali halaman web, gambar, atau data yang diminta. Contoh: Apache, Nginx, Microsoft IIS, LiteSpeed. Di XAMPP, web server yang dipakai adalah Apache.</p><h3>2. Fungsi Web Server</h3><ul><li>Menerima dan memproses permintaan dari browser (client).</li><li>Menyimpan dan menyajikan file website (HTML, CSS, JavaScript, gambar).</li><li>Menjalankan skrip sisi server seperti PHP dan terhubung ke database MySQL.</li><li>Mengatur keamanan akses, log, dan hak akses pengguna.</li><li>Mengelola banyak website sekaligus melalui virtual host.</li></ul><h3>3. Cara Kerja Singkat</h3><pre>Browser --(request HTTP port 80 / HTTPS port 443)--&gt; Web Server\nWeb Server --(proses PHP + query database)--&gt; hasil\nWeb Server --(response: halaman HTML)--&gt; Browser</pre><h3>4. Kelebihan Web Server</h3><ul><li>Website dapat diakses banyak orang kapan saja melalui jaringan atau internet.</li><li>Kontrol penuh atas konfigurasi, data, dan keamanan (jika dikelola sendiri).</li><li>Dapat menjalankan berbagai aplikasi: PHP, database, LMS, dan lain-lain.</li><li>Banyak pilihan gratis dan open source (Apache, Nginx).</li><li>Mudah dikembangkan dan di-update secara terpusat.</li></ul><h3>5. Kekurangan Web Server</h3><ul><li>Membutuhkan biaya perangkat keras, listrik, dan perawatan.</li><li>Rentan serangan (DDoS, SQL injection, peretasan) bila konfigurasi lemah.</li><li>Perlu admin yang memahami konfigurasi dan keamanan.</li><li>Jika server mati, seluruh layanan ikut tidak bisa diakses.</li><li>Kinerja menurun jika jumlah pengunjung melebihi kapasitas.</li></ul>');
INSERT INTO soal(pertanyaan,mapel,a,b,c,d,kunci) VALUES
('Web server adalah perangkat lunak yang berfungsi untuk...','TKJ','Mengedit foto','Menerima permintaan HTTP dan mengirim halaman web ke client','Mengirim email saja','Menghapus virus','B'),
('Berikut ini yang termasuk contoh web server adalah...','TKJ','Apache','Photoshop','Notepad','WinRAR','A'),
('Protokol yang digunakan browser untuk meminta halaman ke web server adalah...','TKJ','SMTP','FTP','HTTP','POP3','C'),
('Port default untuk HTTP adalah...','TKJ','21','80','25','443','B'),
('Port default untuk HTTPS adalah...','TKJ','443','80','22','110','A'),
('Salah satu fungsi web server adalah...','TKJ','Mencetak dokumen','Memperbaiki kabel jaringan','Menyimpan dan menyajikan halaman web','Menggandakan IP address','C'),
('Kelebihan mengelola web server sendiri adalah...','TKJ','Tidak perlu perawatan','Kontrol penuh atas konfigurasi dan data','Tidak pernah error','Tanpa risiko keamanan','B'),
('Kekurangan web server adalah...','TKJ','Butuh biaya, perawatan, dan admin yang paham keamanan','Tidak bisa menyimpan file','Tidak bisa diakses lewat browser','Tidak mendukung PHP','A'),
('XAMPP adalah paket yang berisi...','TKJ','Word, Excel, PowerPoint','Apache, MySQL, PHP, dan Perl','Chrome dan Firefox','Windows dan Linux','B'),
('Folder tempat menyimpan file website pada XAMPP adalah...','TKJ','htdocs','system32','Program Files','Downloads','A');
INSERT INTO evaluasi(nama,mapel,waktu) VALUES('Pengertian, Fungsi, Kelebihan dan Kekurangan Web Server','TKJ',30);
INSERT INTO evaluasi_soal SELECT 1,id FROM soal;

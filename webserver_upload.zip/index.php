<?php
session_start();date_default_timezone_set('Asia/Jakarta');
set_exception_handler(function($e){echo '<meta charset=utf-8><div style="font-family:sans-serif;max-width:640px;margin:40px auto;padding:20px;border:1px solid #e5b4b4;border-radius:12px;background:#fff5f5"><h3>Terjadi kesalahan</h3><p>Silakan kembali dan coba lagi. Jika terus terjadi, kirim pesan ini ke guru/pengembang:</p><pre style="white-space:pre-wrap">'.htmlspecialchars($e->getMessage()).'</pre><a href="index.php">← Kembali ke Beranda</a></div>';exit;});
$op=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];
try{$db=new PDO('mysql:host=localhost;dbname=webserver;charset=utf8mb4','root','',$op);foreach(['users','materi','soal','evaluasi','evaluasi_soal','hasil','jawaban'] as $tb)$db->query("SELECT 1 FROM $tb LIMIT 1");}
catch(PDOException $e1){
 try{$db=new PDO('mysql:host=localhost;charset=utf8mb4','root','',$op);
  foreach(preg_split('/;\s*\n/',file_get_contents(__DIR__.'/sql/webserver.sql')) as $st){if(trim($st)!=='')$db->exec($st);}
  $db->exec('USE webserver');}
 catch(PDOException $e2){exit('<meta charset=utf-8><h3>Gagal menyiapkan database</h3><p>Pastikan MySQL di XAMPP berstatus Running dan password root kosong.</p><pre>'.htmlspecialchars($e2->getMessage()).'</pre>');}}
$db->exec("CREATE TABLE IF NOT EXISTS lkpd(id INT AUTO_INCREMENT PRIMARY KEY,judul VARCHAR(200),tujuan TEXT,petunjuk TEXT,tugas TEXT,created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS lkpd_jawab(id INT AUTO_INCREMENT PRIMARY KEY,lkpd_id INT,user_id INT,jawaban TEXT,nilai INT NULL,catatan TEXT NULL,tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq(lkpd_id,user_id),FOREIGN KEY(lkpd_id) REFERENCES lkpd(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
$lk2=['LKPD 2 - Kelebihan dan Kekurangan Web Server','Peserta didik mampu menganalisis kelebihan dan kekurangan web server serta memahami kode status HTTP.','Gunakan materi dan Pojok Digital sebagai referensi. Jawab dengan kalimat sendiri.',"1. Sebutkan tiga contoh web server dan jelaskan satu ciri masing-masing.\n2. Tuliskan tiga kelebihan mengelola web server sendiri.\n3. Tuliskan tiga kekurangan atau risiko web server beserta cara mengatasinya.\n4. Buka alamat yang tidak ada, misalnya http://localhost/tidakada. Kode status apa yang muncul dan apa artinya?\n5. Jelaskan alur kerja web server dari permintaan browser sampai halaman tampil."];
if(!$db->query("SELECT COUNT(*) FROM lkpd")->fetchColumn()){$ins=$db->prepare("INSERT INTO lkpd(judul,tujuan,petunjuk,tugas) VALUES(?,?,?,?)");
 $ins->execute(['LKPD 1 - Instalasi dan Pengujian Web Server (XAMPP/Apache)','Peserta didik mampu menjalankan web server Apache pada XAMPP, menempatkan file di htdocs, dan mengujinya melalui browser.','Kerjakan secara berurutan dan catat hasil pengamatan pada kolom jawaban. Boleh bekerja berpasangan.',"1. Jalankan Apache pada XAMPP Control Panel. Apa status yang muncul dan pada port berapa Apache berjalan?\n2. Buat folder latihan di dalam htdocs, lalu buat file index.html berisi nama Anda. Tuliskan alamat URL untuk membukanya di browser.\n3. Buka http://localhost dan http://127.0.0.1. Apakah hasilnya sama? Jelaskan.\n4. Jelaskan perbedaan HTTP (port 80) dan HTTPS (port 443).\n5. Tuliskan kesimpulan Anda tentang fungsi web server."]);
 $ins->execute($lk2);}
$db->exec("CREATE TABLE IF NOT EXISTS app_flags(k VARCHAR(50) PRIMARY KEY)");
if(!$db->query("SELECT COUNT(*) FROM app_flags WHERE k='web_only'")->fetchColumn()){
 $db->exec("DELETE FROM materi WHERE judul LIKE 'Konfigurasi Routing%'");
 $dl=$db->prepare("DELETE FROM soal WHERE pertanyaan LIKE ?");
 foreach(['Perintah untuk mengaktifkan IP forwarding','File untuk mengaktifkan IP forwarding','Perintah menampilkan tabel routing','Perintah menambah default gateway','Aturan iptables untuk NAT','File konfigurasi IP statis pada Debian','Fungsi utama router adalah','Perintah menambah static route','Paket yang dipakai agar aturan iptables','Perintah untuk menelusuri jalur paket'] as $x)$dl->execute([$x.'%']);
 $db->exec("DELETE FROM evaluasi WHERE nama LIKE 'Konfigurasi Routing%'");
 $db->exec("DELETE FROM lkpd WHERE judul LIKE 'LKPD 2 - Konfigurasi Routing%'");
 if(!$db->query("SELECT COUNT(*) FROM lkpd WHERE judul LIKE 'LKPD 2 - Kelebihan%'")->fetchColumn())$db->prepare("INSERT INTO lkpd(judul,tujuan,petunjuk,tugas) VALUES(?,?,?,?)")->execute($lk2);
 $db->exec("INSERT INTO app_flags VALUES('web_only')");}
if(!$db->query("SELECT COUNT(*) FROM app_flags WHERE k='siswa36'")->fetchColumn()){
 $sis=siswa36();
 $ia=$db->prepare("INSERT IGNORE INTO users(username,password,nama,role,kelas) VALUES(?,MD5('123'),?,'murid','XI TKJ')");
 foreach($sis as $nm)$ia->execute([strtolower($nm),$nm]);
 $db->exec("INSERT INTO app_flags VALUES('siswa36')");}
if(!$db->query("SELECT COUNT(*) FROM app_flags WHERE k='siswa_only36'")->fetchColumn()){
 $ia=$db->prepare("INSERT IGNORE INTO users(username,password,nama,role,kelas) VALUES(?,MD5('123'),?,'murid','XI TKJ')");$keep=[];
 foreach(siswa36() as $nm){$un=strtolower($nm);$keep[]=$un;$ia->execute([$un,$nm]);}
 $db->prepare("DELETE FROM users WHERE role='murid' AND username NOT IN (".implode(',',array_fill(0,count($keep),'?')).")")->execute($keep);
 $db->exec("UPDATE users SET password=MD5('1234') WHERE username='guru'");
 $db->exec("INSERT INTO app_flags VALUES('siswa_only36')");}
function siswa36(){return ['Adhisakti Damar Pamungkas','Adilla Ayu Rahmawati','Aisyah Aninda Okta','Aisyah Arumi Damayanti','Aisyah Cahyowati','Aldo Setyawan','Alfafa Azura Najit','Alfinah Robithoh','Ameel Sonia Benata','Ananda Habib Bayhaqi','Andrea Rizky Pratama','Anisah Sekar Winiastuti','Aprilia Naura Putri','Ardias Vidi Prasetyo','Arron Nico Firjatullah','Auliadiah Ayu Kusuma Wati','Aulya Miftahul Jannah','Aura Eka Saputri','Ayu Febriyana','Azzahra Syifa Rahmadhani','Bangun Pratama','Bilalfi Arohmah Sutrisno','Bima Arya Herlambang','Dana Salsa Bela','Darmawan Aditya Pratama','Deka Wijaya Kusuma','Dhera Amelya Rahmadhani','Dia Salma Salsabila','Dimas Dwi Prakoso','Dwi Karsari Nafisa Rahma','Eka Yhulasna Saputra','Erland Oktaviansyah','Faidatun Fauziah','Fairus Fathihul Ihsan Hersaputra','Fairush Syiwi Anjani','Farid Rifqi At Thariq'];}
function q($s,$a=[]){global $db;$t=$db->prepare($s);$t->execute($a);return $t;}
function h($s){return htmlspecialchars((string)$s);}
function tgl($d,$full=false){$H=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];$B=['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];$t=strtotime($d);return $full?$H[date('w',$t)].', '.date('j',$t).' '.$B[(int)date('n',$t)].' '.date('Y',$t):date('d-m-Y',$t);}
function tb($n){$s=['nol','satu','dua','tiga','empat','lima','enam','tujuh','delapan','sembilan','sepuluh','sebelas'];if($n<12)return $s[$n];if($n<20)return $s[$n-10].' belas';if($n<100)return $s[intdiv($n,10)].' puluh'.($n%10?' '.$s[$n%10]:'');return 'seratus';}
function pred($n){global $KKM;return $n>=90?'Sangat Baik':($n>=80?'Baik':($n>=$KKM?'Cukup':'Belum Tuntas'));}
function certhtml($r){global $KKM;$n=(int)$r['nilai'];$ok=$n>=$KKM;$no=sprintf('%03d/LMS-TKJ/%s',(int)$r['id'],date('Y',strtotime($r['tanggal'])));
return '<div class=cert2><div class=c2in><span class="cn a">❖</span><span class="cn b">❖</span><span class="cn c">❖</span><span class="cn d">❖</span><img class=wm src="img/logo-smk-juwiring.jpg" alt="">
<div class=c2top><img class=lgo src="img/logo-smk-juwiring.jpg" alt="Logo SMK N 1 Juwiring"><div class=c2sch2><b>SMK NEGERI 1 JUWIRING</b><br><small>Kabupaten Klaten &bull; Teknik Komputer dan Jaringan</small><br><small>LMS TKJ &bull; Pembelajaran Web Server</small></div><img class=lgo src="img/logo-smk-bisa-hebat.jpg" alt="Logo SMK Bisa Hebat"></div><div class=c2no2>No. '.$no.'</div>
<h1>SERTIFIKAT</h1><div class=c2sub>PENGHARGAAN HASIL EVALUASI</div><p class=c2p>Diberikan kepada</p><div class=c2name>'.h(ucwords($r['username'])).'</div><p class=c2p>telah berhasil menyelesaikan evaluasi</p><div class=c2ev>'.h($r['en']).'</div><p class=c2p>dengan nilai</p>
<div class=c2score><div class=ring style="--v:'.$n.';width:104px;height:104px"><b>'.$n.'</b></div><div><div class=c2tb>('.ucwords(tb($n)).')</div><span class=c2pr>Predikat: '.pred($n).'</span><br>'.($ok?'<b class=ok>LULUS</b>':'<b class=no>BELUM LULUS</b>').' &bull; '.$r['benar'].' benar dari '.$r['total'].' soal</div></div>
<div class=c2ft><div><div class=c2ln></div><small>'.tgl($r['tanggal']).'</small></div><svg class=rosette viewBox="0 0 100 130" aria-hidden="true"><path d="M30 80L18 125L40 112L50 128L58 82Z" fill="#9c1f2a"/><path d="M70 80L82 125L60 112L50 128L42 82Z" fill="#b8323f"/><circle cx="50" cy="50" r="40" fill="#d4af37"/><circle cx="50" cy="50" r="32" fill="#f4e08a" stroke="#b8901c" stroke-width="3"/><text x="50" y="62" text-anchor="middle" font-size="34" fill="#8a6a0c" font-family="Georgia,serif">★</text></svg><div><div class=c2ln></div><small>Guru Mata Pelajaran</small></div></div>
</div></div>';}
function hd($t){echo '<div class=ph><h2>'.$t.'</h2><span class=dt>'.tgl('now',1).'</span></div>';}
function zipopen($path){$d=@file_get_contents($path);$f=[];if($d===false)return [null,$f];$p=strrpos($d,"PK\x05\x06");if($p===false)return [$d,$f];
 $e=unpack('vdk/vcd/vn1/vn2/Vsz/Vof/vcl',substr($d,$p+4,18));$pos=$e['of'];
 for($i=0;$i<$e['n2'];$i++){if(substr($d,$pos,4)!=="PK\x01\x02")break;
  $h=unpack('vma/vne/vfl/vme/vti/vda/Vcr/Vcs/Vus/vnl/vel/vcl/vds/vit/Vea/Vlo',substr($d,$pos+4,42));
  $nm=substr($d,$pos+46,$h['nl']);$f[$nm]=[$h['me'],$h['cs'],$h['lo']];$pos+=46+$h['nl']+$h['el']+$h['cl'];}
 return [$d,$f];}
function zipread($z,$nm){$d=$z[0];$f=$z[1];if(!isset($f[$nm]))return null;$me=$f[$nm][0];$cs=$f[$nm][1];$lo=$f[$nm][2];
 if(substr($d,$lo,4)!=="PK\x03\x04")return null;$l=unpack('vnl/vel',substr($d,$lo+26,4));$s=substr($d,$lo+30+$l['nl']+$l['el'],$cs);
 if($me==0)return $s;if($me==8&&function_exists('gzinflate')){$x=@gzinflate($s);return $x===false?null:$x;}return null;}
function zipbuild($files){$out='';$cd='';$n=0;
 foreach($files as $name=>$data){$crc=crc32($data);$us=strlen($data);$cmp=$data;$me=0;
  if(function_exists('gzdeflate')){$z=gzdeflate($data);if($z!==false&&strlen($z)<$us){$cmp=$z;$me=8;}}
  $cs=strlen($cmp);$off=strlen($out);
  $out.="PK\x03\x04".pack('vvvvvVVVvv',20,0,$me,0,0x21,$crc,$cs,$us,strlen($name),0).$name.$cmp;
  $cd.="PK\x01\x02".pack('vvvvvvVVVvvvvvVV',20,20,0,$me,0,0x21,$crc,$cs,$us,strlen($name),0,0,0,0,0,$off).$name;$n++;}
 return $out.$cd."PK\x05\x06".pack('vvvvVVv',0,0,$n,$n,strlen($cd),strlen($out),0);}
function zipsend($files,$name,$mime){$bin=zipbuild($files);header("Content-Type: $mime");header("Content-Disposition: attachment; filename=$name");header('Content-Length: '.strlen($bin));echo $bin;exit;}
function xlsx($H,$R,$name){$x='';foreach(array_merge([$H],$R) as $i=>$row){$x.='<row r="'.($i+1).'">';foreach(array_values($row) as $j=>$c){$ref=chr(65+$j).($i+1);$x.=(is_numeric($c)&&$i)?'<c r="'.$ref.'"><v>'.$c.'</v></c>':'<c r="'.$ref.'" t="inlineStr"><is><t>'.htmlspecialchars((string)$c).'</t></is></c>';}$x.='</row>';}
 $X='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';$rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships';$pk='http://schemas.openxmlformats.org/package/2006/relationships';
 zipsend(['[Content_Types].xml'=>$X.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
 '_rels/.rels'=>$X.'<Relationships xmlns="'.$pk.'"><Relationship Id="rId1" Type="'.$rel.'/officeDocument" Target="xl/workbook.xml"/></Relationships>',
 'xl/workbook.xml'=>$X.'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'.$rel.'"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>',
 'xl/_rels/workbook.xml.rels'=>$X.'<Relationships xmlns="'.$pk.'"><Relationship Id="rId1" Type="'.$rel.'/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
 'xl/worksheets/sheet1.xml'=>$X.'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'.$x.'</sheetData></worksheet>'],$name,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');}
function docx($ti,$H,$R,$name){$e=function($v){return htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES,'UTF-8');};
 $cell=function($v,$b=false)use($e){return '<w:tc><w:tcPr><w:tcW w:w="2200" w:type="dxa"/></w:tcPr><w:p><w:r>'.($b?'<w:rPr><w:b/></w:rPr>':'').'<w:t xml:space="preserve">'.$e($v).'</w:t></w:r></w:p></w:tc>';};
 $b='';foreach(['top','left','bottom','right','insideH','insideV'] as $k)$b.='<w:'.$k.' w:val="single" w:sz="4" w:space="0" w:color="888888"/>';
 $t='<w:tbl><w:tblPr><w:tblBorders>'.$b.'</w:tblBorders></w:tblPr><w:tblGrid>'.str_repeat('<w:gridCol w:w="2200"/>',count($H)).'</w:tblGrid><w:tr>';foreach($H as $c)$t.=$cell($c,true);$t.='</w:tr>';
 foreach($R as $r){$t.='<w:tr>';foreach($r as $c)$t.=$cell($c);$t.='</w:tr>';}$t.='</w:tbl>';
 $X='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
 zipsend(['[Content_Types].xml'=>$X.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
 '_rels/.rels'=>$X.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
 'word/document.xml'=>$X.'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:rPr><w:b/><w:sz w:val="32"/></w:rPr><w:t>'.$e($ti).'</w:t></w:r></w:p>'.$t.'<w:p/></w:body></w:document>'],$name,'application/vnd.openxmlformats-officedocument.wordprocessingml.document');}
function laporan($eid,$kl){$w=' WHERE 1=1';$a=[];if($eid){$w.=' AND h.evaluasi_id=?';$a[]=$eid;}if($kl!==''){$w.=' AND u.kelas=?';$a[]=$kl;}
 return q("SELECT u.nama,h.nilai,IF(h.nilai>=75,'Lulus','Tidak Lulus') ket FROM hasil h JOIN users u ON u.id=h.user_id$w ORDER BY h.nilai DESC",$a)->fetchAll();}
function rows(){$n=$_FILES['f']['name'];$e=strtolower(pathinfo($n,PATHINFO_EXTENSION));$t=$_FILES['f']['tmp_name'];$r=[];
 if($e=='csv'||$e=='txt'){$raw=preg_replace('/^\xEF\xBB\xBF/','',(string)file_get_contents($t));foreach(preg_split('/\r\n|\r|\n/',$raw) as $l){if(trim($l)==='')continue;$d=strpos($l,'|')!==false?'|':(strpos($l,';')!==false?';':(strpos($l,"\t")!==false?"\t":','));$r[]=str_getcsv(trim($l),$d);}}
 elseif($e=='pdf'){$d=file_get_contents($t);preg_match_all('/stream\r?\n(.*?)endstream/s',$d,$m);$txt='';
  foreach($m[1] as $st){$x=@gzuncompress($st);if($x===false)$x=@gzinflate(substr($st,2));if($x===false)continue;
   preg_match_all('/\[(.*?)\]\s*TJ|\(((?:\\\\.|[^\\\\)])*)\)\s*Tj|(ET)/s',$x,$mm,PREG_SET_ORDER);
   foreach($mm as $k){if(!empty($k[3])){$txt.="\n";continue;}$src=$k[1]!==''?$k[1]:'('.($k[2]??'').')';preg_match_all('/\(((?:\\\\.|[^\\\\)])*)\)/',$src,$pp);foreach($pp[1] as $w)$txt.=stripslashes($w);}}
  foreach(explode("\n",$txt) as $l)if(trim($l))$r[]=explode('|',$l);}
 elseif($e=='docx'){$z=zipopen($t);$x=zipread($z,'word/document.xml');preg_match_all('/<w:p[ >].*?<\/w:p>/s',(string)$x,$m);foreach($m[0] as $pp){$l=html_entity_decode(strip_tags(str_replace('<w:tab/>','|',$pp)));if(trim($l))$r[]=explode('|',$l);}}
 elseif($e=='xlsx'){$z=zipopen($t);$ss=[];$x=zipread($z,'xl/sharedStrings.xml');
  if($x){preg_match_all('/<si>(.*?)<\/si>/s',$x,$m);foreach($m[1] as $s)$ss[]=html_entity_decode(strip_tags($s),ENT_QUOTES|ENT_XML1,'UTF-8');}
  $nms=[];foreach(array_keys($z[1]) as $nm){if(preg_match('#^xl/worksheets/sheet\d+\.xml$#',$nm))$nms[]=$nm;}natsort($nms);
  foreach($nms as $nm){$x=(string)zipread($z,$nm);preg_match_all('/<row\b[^>]*?(?:\/>|>.*?<\/row>)/s',$x,$m);
   foreach($m[0] as $row){preg_match_all('/<c\b([^>]*?)(?:\/>|>(.*?)<\/c>)/s',$row,$c,PREG_SET_ORDER);$o=[];
    foreach($c as $cc){$in=$cc[2]??'';$v='';if(preg_match('/<v>(.*?)<\/v>/s',$in,$vv))$v=$vv[1];elseif(preg_match('/<t[^>]*>(.*?)<\/t>/s',$in,$vv))$v=$vv[1];
     if(strpos($cc[1],'t="s"')!==false)$v=$ss[(int)$v]??'';else $v=html_entity_decode($v,ENT_QUOTES|ENT_XML1,'UTF-8');
     $idx=count($o);if(preg_match('/r="([A-Z]+)\d+"/',$cc[1],$cm)){$idx=0;foreach(str_split($cm[1]) as $ch)$idx=$idx*26+ord($ch)-64;$idx--;}
     $o[$idx]=$v;}
    if($o){ksort($o);$r[]=$o;}}
   if($r)break;}}
 return $r;}
$u=$_SESSION['u']??null;if($u){$u=q("SELECT * FROM users WHERE id=?",[$u['id']])->fetch()?:null;if($u)$_SESSION['u']=$u;else unset($_SESSION['u']);}$p=$_GET['p']??'dashboard';$G=$u&&$u['role']=='guru';
// ===== Login / Logout =====
if($p=='login'&&$_SERVER['REQUEST_METHOD']=='POST'){$un=substr(strtolower(trim(preg_replace('/\s+/',' ',$_POST['username']??''))),0,50);$pw=(string)($_POST['password']??'');
 if($un==='')$err='Isi username dengan nama lengkap Anda.';
 else{$r=q("SELECT * FROM users WHERE username=?",[$un])->fetch();
  if($r){if(md5($pw)===$r['password']){$_SESSION['u']=$r;header('Location: index.php');exit;}$err='Password salah.';}
  elseif($pw==='123'&&q("SELECT COUNT(*) FROM app_flags WHERE k='auto_daftar'")->fetchColumn()){q("INSERT INTO users(username,password,nama,role) VALUES(?,MD5('123'),?,'murid')",[$un,ucwords($un)]);$r=q("SELECT * FROM users WHERE id=?",[$db->lastInsertId()])->fetch();$_SESSION['u']=$r;header('Location: index.php');exit;}
  else $err='Nama belum terdaftar. Periksa ejaan nama lengkap Anda atau hubungi guru.';}}
if($p=='logout'){session_destroy();header('Location: index.php?p=login');exit;}
if(!$u)$p='login';
if($p=='login'){?><!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>LMS TKJ</title><link rel=stylesheet href=css/style.css><link rel=stylesheet href=css/glass.css>
<div class=login><div class=lbox><div class=lf><img src=img/logo.svg width=70 alt=""><h1>LMS TKJ</h1><p>Learning Management System<br>SMK Teknik Komputer dan Jaringan</p><?php if(!empty($err))echo "<p class=no>$err</p>"?>
<form method=post action="index.php?p=login"><label>Username (nama lengkap)</label><input name=username placeholder="Contoh: aldo setyawan" required autofocus><label>Password</label><input type=password name=password placeholder="Password" required><button class=btn style="width:100%;padding:11px">Login</button></form>
<small>Murid: isi nama lengkap sesuai daftar kelas dan password dari guru.</small></div>
<div class=rt><img src=img/rack.svg alt="" style="width:100%;border-radius:10px"><h3>Belajar • Berlatih • Berprestasi</h3><p>Dengan LMS TKJ, proses belajar lebih mudah dan terarah.</p><div class=feat><span>📚 Materi</span><span>📝 Evaluasi Otomatis</span><span>🏅 Sertifikat</span><span>📄 Word · Excel · PDF</span></div></div></div></div><?php exit;}
$KKM=75;
// ===== POST =====
if($_SERVER['REQUEST_METHOD']=='POST'){$a=$_POST['act']??'';$go=$p;
 if($G){
  if($a=='soal'){$go='soal';$v=[$_POST['pertanyaan'],$_POST['mapel'],$_POST['a'],$_POST['b'],$_POST['c'],$_POST['d'],$_POST['kunci']];
   if(!empty($_POST['id']))q("UPDATE soal SET pertanyaan=?,mapel=?,a=?,b=?,c=?,d=?,kunci=? WHERE id=?",array_merge($v,[$_POST['id']]));else{q("INSERT INTO soal(pertanyaan,mapel,a,b,c,d,kunci) VALUES(?,?,?,?,?,?,?)",$v);if(!empty($_POST['ev']))q("INSERT IGNORE INTO evaluasi_soal VALUES(?,?)",[$_POST['ev'],$db->lastInsertId()]);}}
  if($a=='delsoal')q("DELETE FROM soal WHERE id=?",[$_POST['id']]);
  if($a=='import'){$go='soal';$ids=[];if(isset($_FILES['f'])&&$_FILES['f']['error']==0){foreach(rows() as $x){$x=array_map('trim',array_map('strval',$x));$kj=strtoupper($x[5]??'');if(($x[0]??'')!==''&&in_array($kj,['A','B','C','D'])){q("INSERT INTO soal(pertanyaan,a,b,c,d,kunci) VALUES(?,?,?,?,?,?)",[$x[0],$x[1]??'',$x[2]??'',$x[3]??'',$x[4]??'',$kj]);$ids[]=$db->lastInsertId();}}
    if($ids){q("INSERT INTO evaluasi(nama,mapel,waktu) VALUES(?,?,?)",['Evaluasi - '.pathinfo($_FILES['f']['name'],PATHINFO_FILENAME),'TKJ',60]);$eid=$db->lastInsertId();foreach($ids as $sid)q("INSERT INTO evaluasi_soal VALUES(?,?)",[$eid,$sid]);}}
   $_SESSION['msg']=$ids?count($ids).' soal berhasil diimpor: otomatis masuk Bank Soal (guru dan murid) dan Evaluasi baru lengkap dengan kunci jawaban.':'Tidak ada soal terbaca. Cek format: Pertanyaan | A | B | C | D | Kunci (PDF hanya didukung jika teksnya bisa dibaca; jika gagal gunakan Word/Excel).';}
  if($a=='evaluasi'){q("INSERT INTO evaluasi(nama,mapel,waktu) VALUES(?,?,?)",[$_POST['nama'],'TKJ',(int)$_POST['waktu']]);$id=$db->lastInsertId();foreach($_POST['ids']??[] as $s)q("INSERT INTO evaluasi_soal VALUES(?,?)",[$id,$s]);}
  if($a=='delev')q("DELETE FROM evaluasi WHERE id=?",[$_POST['id']]);
  if($a=='murid')q("INSERT IGNORE INTO users(username,password,nama,role) VALUES(?,MD5('123'),?,'murid')",[strtolower(trim($_POST['username'])),$_POST['nama']]);
  if($a=='murid_import'){$go='murid';$n=0;$up=0;$sk=0;$tot=0;$kl=trim($_POST['kelas']??'')?:'XI TKJ';$rw=[];$info='';$tp=trim($_POST['tempel']??'');
   if($tp!==''){foreach(preg_split('/\r\n|\r|\n/',$tp) as $l){if(trim($l)!=='')$rw[]=[$l];}}
   elseif(isset($_FILES['f'])&&$_FILES['f']['error']==0){$ex=strtolower(pathinfo($_FILES['f']['name'],PATHINFO_EXTENSION));
    if($ex=='xls')$info='Format .xls (Excel lama) tidak didukung. Buka di Excel lalu Save As .xlsx atau CSV.';
    else $rw=rows();}
   elseif(isset($_FILES['f'])&&$_FILES['f']['error']!=4)$info='Upload file gagal (kode '.$_FILES['f']['error'].'). Coba file yang lebih kecil atau tempel daftar nama.';
   else $info='Belum ada file yang dipilih dan kotak tempel kosong.';
   $col=-1;foreach(array_slice($rw,0,6) as $x){foreach($x as $k=>$c){if(in_array(strtolower(trim((string)$c)),['nama','nama siswa','nama murid','nama lengkap','name'])){$col=$k;break 2;}}}
   foreach($rw as $x){$nm='';
    if($col>=0)$nm=trim((string)($x[$col]??''));
    else{foreach($x as $c){$c=trim((string)$c);if(strlen($c)>strlen($nm)&&preg_match('/[A-Za-z]{2,}/',$c))$nm=$c;}}
    $nm=substr($nm,0,100);$un=substr(strtolower(trim(preg_replace('/\s+/',' ',$nm))),0,50);
    if($un===''||$un==='guru'||is_numeric($un)||in_array($un,['nama','nama siswa','nama murid','nama lengkap','name','no','nis','kelas']))continue;
    $tot++;$r=q("INSERT INTO users(username,password,nama,role,kelas) VALUES(?,MD5('123'),?,'murid',?) ON DUPLICATE KEY UPDATE kelas=IF(role='murid',VALUES(kelas),kelas)",[$un,$nm,$kl]);$rc=$r->rowCount();
    if($rc==1)$n++;elseif($rc==2)$up++;else $sk++;}
   $_SESSION['msg']=$info?$info:($tot?"$tot nama terbaca: $n murid baru diimpor ke kelas $kl".($up?", $up murid lama dipindahkan ke kelas $kl":'').($sk?", $sk sudah terdaftar di kelas itu":'').'. Password awal: 123.':'Tidak ada nama murid yang terbaca ('.count($rw).' baris dibaca). Pastikan ada kolom Nama, atau tempel daftar nama (satu nama per baris) di kotak yang tersedia.');}
  if($a=='set_auto'){$go='pengaturan';if(($_POST['v']??'0')=='1')q("INSERT IGNORE INTO app_flags VALUES('auto_daftar')");else q("DELETE FROM app_flags WHERE k='auto_daftar'");$_SESSION['msg']=(($_POST['v']??'0')=='1')?'Daftar otomatis diaktifkan.':'Daftar otomatis dimatikan. Hanya murid di Data Murid yang bisa login.';}
  if($a=='murid_contoh'){$go='murid';$n=0;$ia=$db->prepare("INSERT IGNORE INTO users(username,password,nama,role,kelas) VALUES(?,MD5('123'),?,'murid','XI TKJ')");foreach(siswa36() as $nm){$ia->execute([strtolower($nm),$nm]);$n+=$ia->rowCount();}$_SESSION['msg']="$n murid contoh ditambahkan (kelas XI TKJ). Password awal: 123.";}
  if($a=='materi')q("INSERT INTO materi(judul,isi) VALUES(?,?)",[$_POST['judul'],$_POST['isi']]);
  if($a=='reset')q("DELETE FROM hasil");
  if($a=='lkpd_add'){$go='lkpd';q("INSERT INTO lkpd(judul,tujuan,petunjuk,tugas) VALUES(?,?,?,?)",[$_POST['judul'],$_POST['tujuan'],$_POST['petunjuk'],$_POST['tugas']]);}
  if($a=='lkpd_del'){$go='lkpd';q("DELETE FROM lkpd WHERE id=?",[$_POST['id']]);}
  if($a=='lkpd_nilai'){$go='lkpdbuka&id='.(int)$_POST['lid'];q("UPDATE lkpd_jawab SET nilai=?,catatan=? WHERE id=?",[$_POST['nilai']===''?null:(int)$_POST['nilai'],$_POST['catatan'],$_POST['id']]);}
 }
 if($a=='lkpd_kirim'&&!$G){$lid=(int)$_POST['lid'];$go='lkpdbuka&id='.$lid;q("INSERT INTO lkpd_jawab(lkpd_id,user_id,jawaban) VALUES(?,?,?) ON DUPLICATE KEY UPDATE jawaban=VALUES(jawaban),nilai=NULL,catatan=NULL",[$lid,$u['id'],$_POST['jawaban']]);$_SESSION['msg']='Jawaban LKPD berhasil dikirim.';}
 if($a=='submit'&&!$G){$e=(int)$_POST['eid'];$ss=q("SELECT s.* FROM soal s JOIN evaluasi_soal x ON x.soal_id=s.id WHERE x.evaluasi_id=?",[$e])->fetchAll();
  if(!$ss){$_SESSION['msg']='Evaluasi ini belum memiliki soal.';header('Location: index.php?p=evaluasi');exit;}
  $db->beginTransaction();
  try{$b=0;q("INSERT INTO hasil(user_id,evaluasi_id,nilai,benar,total) VALUES(?,?,0,0,?)",[$u['id'],$e,count($ss)]);$hid=$db->lastInsertId();
   foreach($ss as $s){$j=strtoupper(substr((string)($_POST['ans'][$s['id']]??''),0,1));if($j===$s['kunci'])$b++;q("INSERT INTO jawaban(hasil_id,soal_id,jawab) VALUES(?,?,?)",[$hid,$s['id'],$j]);}
   q("UPDATE hasil SET benar=?,nilai=? WHERE id=?",[$b,(int)round($b/count($ss)*100),$hid]);$db->commit();}
  catch(Exception $x){$db->rollBack();throw $x;}
  header("Location: index.php?p=detail&id=$hid");exit;}
 header("Location: index.php?p=$go");exit;}
if($p=='templatemurid'&&$G){header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=template_murid.csv');echo "\xEF\xBB\xBFNama\nAndi Pratama\nBudi Santoso\nCitra Dewi\n";exit;}
// ===== Export =====
if($p=='export'&&$G){$t=$_GET['t']??'hasil';$f=$_GET['f']??'xlsx';
 if($t=='soal'){$H=['No','Pertanyaan','A','B','C','D','Kunci'];$R=[];foreach(q("SELECT pertanyaan,a,b,c,d,kunci FROM soal")->fetchAll(PDO::FETCH_NUM) as $i=>$r)$R[]=array_merge([$i+1],$r);$ti='Bank Soal';}
 else{$H=['No','Nama Murid','Nilai','Keterangan'];$R=[];foreach(laporan((int)($_GET['e']??0),$_GET['k']??'') as $i=>$r)$R[]=[$i+1,$r['nama'],$r['nilai'],$r['ket']];$ti='Laporan Hasil Evaluasi';}
 if($f=='xlsx')xlsx($H,$R,"$t.xlsx");if($f=='docx')docx($ti,$H,$R,"$t.docx");
 $o='<meta charset=utf-8><title>'.$ti.'</title><h2>LMS TKJ - '.$ti.'</h2><table border=1 cellpadding=6 style="border-collapse:collapse;font-family:Arial"><tr>';foreach($H as $c)$o.="<th>$c</th>";$o.='</tr>';
 foreach($R as $r){$o.='<tr>';foreach($r as $c)$o.='<td>'.h($c).'</td>';$o.='</tr>';}echo $o.'</table><script>print()</script>';exit;}
// ===== Sertifikat =====
if($p=='cert'){$r=q("SELECT h.*,u.nama,u.username,e.nama en FROM hasil h JOIN users u ON u.id=h.user_id JOIN evaluasi e ON e.id=h.evaluasi_id WHERE h.id=?",[$_GET['id']??0])->fetch();
 if(!$r||$G||$r['user_id']!=$u['id'])exit('<meta charset=utf-8>Sertifikat tidak ditemukan. <a href="index.php">Kembali</a>');
 if(($_GET['f']??'')=='doc'){$n=(int)$r['nilai'];header('Content-Type: application/msword');header('Content-Disposition: attachment; filename=sertifikat.doc');echo '<meta charset=utf-8><div style="text-align:center;border:10px double #b8901c;padding:36px;font-family:Georgia,serif;background:#fffdf4"><p style="letter-spacing:3px;font-size:13px">SMK NEGERI 1 JUWIRING, KLATEN</p><h1 style="font-size:46px;letter-spacing:10px;color:#7a5c0e;margin:6px">SERTIFIKAT</h1><p style="letter-spacing:4px;font-size:12px">PENGHARGAAN HASIL EVALUASI</p><p><i>Diberikan kepada</i></p><h2 style="font-size:34px;color:#1c3b5a"><i>'.h(ucwords($r['username'])).'</i></h2><p><i>telah berhasil menyelesaikan evaluasi</i></p><p style="font-size:18px"><b>'.h($r['en']).'</b></p><p><i>dengan nilai</i></p><h1 style="font-size:56px;color:#7a5c0e;margin:0">'.$n.'</h1><p>('.ucwords(tb($n)).') &bull; Predikat: <b>'.pred($n).'</b></p><p>'.$r['benar'].' benar dari '.$r['total'].' soal</p><p>No. '.sprintf('%03d/LMS-TKJ/%s',(int)$r['id'],date('Y',strtotime($r['tanggal']))).'<br>'.tgl($r['tanggal']).'</p><br><p>______________________<br>Guru Mata Pelajaran</p></div>';exit;}
 echo '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><link rel=stylesheet href=css/style.css><link rel=stylesheet href=css/glass.css><div class=noprint style="text-align:center;padding:14px"><button class="btn r" onclick=print()>⬇ Download PDF</button> <a class=btn href="index.php?p=cert&id='.(int)$r['id'].'&f=doc">⬇ Download Word</a> <button class="btn gr" onclick=print()>🖨 Cetak</button> <a class="btn o" href="index.php?p=detail&id='.(int)$r['id'].'">Kembali</a></div>'.certhtml($r);exit;}
// ===== Layout =====
if(!$G&&in_array($p,['soal','soalform','impor','evsoal','murid','laporan','pengaturan']))$p='dashboard';
if($G&&in_array($p,['sertifikat','kerja','profil']))$p='dashboard';
$M=$G?['dashboard'=>'◫|Beranda','materi'=>'▤|Materi','digital'=>'✧|Pojok Digital','lkpd'=>'✎|LKPD','soal'=>'▤|Bank Soal','hasil'=>'✦|Hasil / Nilai','murid'=>'☺|Data Murid','laporan'=>'☷|Laporan','pengaturan'=>'⚙|Pengaturan']:['dashboard'=>'◫|Beranda','materi'=>'▤|Materi','digital'=>'✧|Pojok Digital','lkpd'=>'✎|LKPD','evaluasi'=>'☷|Evaluasi','hasil'=>'✦|Hasil &amp; Sertifikat','profil'=>'☺|Profil'];
$on=['kerja'=>'evaluasi','detail'=>'hasil','soalform'=>'soal','impor'=>'soal','lkpdbuka'=>'lkpd','evsoal'=>'soal'][$p]??$p;if($G&&$on=='evaluasi')$on='soal';if(!$G&&$on=='sertifikat')$on='hasil';
function daftar($cert){global $G,$u;$w=$G?'':' WHERE h.user_id='.(int)$u['id'];
 echo '<div class=card><table><tr><th>No'.($G?'<th>Nama Murid':'').'<th>Nama Evaluasi<th>Nilai<th>Tanggal<th>Aksi</tr>';
 foreach(q("SELECT h.*,u.nama,e.nama en FROM hasil h JOIN users u ON u.id=h.user_id JOIN evaluasi e ON e.id=h.evaluasi_id$w ORDER BY h.id DESC")->fetchAll() as $i=>$r)echo '<tr><td>'.($i+1).($G?'<td>'.h($r['nama']):'').'<td>'.h($r['en']).'<td><b>'.$r['nilai'].'</b><td>'.tgl($r['tanggal']).'<td>'.($cert?'':'<a class="btn sm" href="index.php?p=detail&id='.$r['id'].'">Detail</a> ').($G?'':'<a class="btn sm g" href="index.php?p=cert&id='.$r['id'].'" target=_blank>Sertifikat</a>').'</tr>';
 echo '</table></div>';}
?><!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>LMS TKJ</title><link rel=stylesheet href=css/style.css><link rel=stylesheet href=css/glass.css>
<div class=top><button class=burger onclick="document.body.classList.toggle('nav')">☰</button><b class=brandtop>LMS TKJ</b><span class=sp></span><button class=pbtn onclick="pres()">🖥 Presentasi</button><span class=pill><?=strtoupper($u['role'])?></span><span class=av><?=h(strtoupper(preg_match('/./u',$u['nama'],$m0)?$m0[0]:'?'))?></span></div><div class=wrap><div class=ov onclick="document.body.classList.remove('nav')"></div><nav class=side><div class=brand><img src=img/logo.svg width=44 alt=""><div><b>LMS TKJ</b><br><small>SMK Teknik Komputer dan Jaringan</small></div></div><div class=lbl>MENU UTAMA</div>
<?php foreach($M as $k=>$v){[$ic,$tx]=explode('|',$v);echo "<a href='index.php?p=$k' class='".($on==$k?'on':'')."'><i>$ic</i>$tx</a>";}?><div class=promo><b>Belajar lebih cerdas</b><br><small>Materi, kuis, dan sertifikat di satu tempat.</small></div><a class=out href="index.php?p=logout"><i>↪</i>Keluar akun</a></nav><main>
<?php
if(!empty($_SESSION['msg'])&&$p!='soal'){echo '<div class="card hero">'.h($_SESSION['msg']).'</div>';unset($_SESSION['msg']);}
if($p=='dashboard'){echo '<div class=ph><span class=dt>'.tgl('now',1).'</span></div><div class=hero2><span class=chip2>'.($G?'RUANG GURU':'RUANG BELAJAR').'</span><h1>Halo, '.h($u['nama']).'!</h1><p>'.($G?'Kelola soal, evaluasi, nilai, dan laporan dengan mudah.':'Pelajari materi web server, lalu uji kemampuanmu lewat evaluasi.').'</p><a class="btn w" href="index.php?p='.($G?'soal':'materi').'">'.($G?'Buka Bank Soal':'Mulai Belajar').'</a> <a class="btn wo" href="index.php?p='.($G?'lkpd':'evaluasi').'">'.($G?'Buka LKPD':'Kerjakan Evaluasi').'</a></div><div class=grid>';
 $bs=q("SELECT COUNT(*) FROM soal")->fetchColumn();
 if($G){$s=[['Bank Soal',$bs,'pertanyaan tersedia'],['Evaluasi',q("SELECT COUNT(*) FROM evaluasi")->fetchColumn(),'evaluasi aktif'],['Murid',q("SELECT COUNT(*) FROM users WHERE role='murid'")->fetchColumn(),'murid terdaftar'],['Rata-rata Nilai',round(q("SELECT AVG(nilai) FROM hasil")->fetchColumn()),'seluruh hasil evaluasi']];}
 else{$nl=q("SELECT nilai FROM hasil WHERE user_id=? ORDER BY id DESC LIMIT 1",[$u['id']])->fetchColumn();$s=[['LKPD',(int)q("SELECT COUNT(*) FROM lkpd")->fetchColumn(),'lembar kerja tersedia'],['Nilai terakhir',$nl===false?'—':$nl,'hasil penilaian'],['Evaluasi',q("SELECT COUNT(*) FROM evaluasi")->fetchColumn(),'evaluasi tersedia'],['Sertifikat',q("SELECT COUNT(*) FROM hasil WHERE user_id=?",[$u['id']])->fetchColumn(),'sertifikat diraih']];}
 $ic=$G?['📘','📝','👥','📊']:['📘','⭐','📝','🏅'];foreach($s as $i=>$x)echo "<div class='sc k".($i+1)."'><em>$ic[$i]</em><small>$x[0]</small><b>$x[1]</b><span>$x[2]</span></div>";echo '</div>';
 if($G){$tot=(int)q("SELECT COUNT(*) FROM hasil")->fetchColumn();$lu=(int)q("SELECT COUNT(*) FROM hasil WHERE nilai>=?",[$KKM])->fetchColumn();$pl=$tot?round($lu/$tot*100):0;
 echo '<div class=cols><div class=card><b>📊 Rata-rata Nilai per Murid</b>';$rw=q("SELECT u.nama,ROUND(AVG(h.nilai)) n FROM hasil h JOIN users u ON u.id=h.user_id GROUP BY u.id,u.nama ORDER BY n DESC LIMIT 8")->fetchAll();
 if(!$rw)echo '<p class=mut>Belum ada hasil evaluasi.</p>';foreach($rw as $r)echo '<div class=br><span>'.h($r['nama']).'</span><div class=bt><div style="width:'.(int)$r['n'].'%"></div></div><b>'.(int)$r['n'].'</b></div>';
 echo '</div><div class="card dn"><b>🎯 Tingkat Kelulusan</b><div class=ring style="--v:'.$pl.';width:130px;height:130px;margin:14px auto"><b>'.$pl.'%</b></div><small>'.$lu.' lulus dari '.$tot.' pengerjaan (KKM '.$KKM.')</small></div></div>';}
else{$rw=array_reverse(q("SELECT nilai FROM hasil WHERE user_id=? ORDER BY id DESC LIMIT 6",[$u['id']])->fetchAll());echo '<div class=card><b>📈 Riwayat Nilai</b>';if(!$rw)echo '<p class=mut>Belum ada nilai. Kerjakan evaluasi pertamamu!</p>';else{echo '<div class=vb>';foreach($rw as $r)echo '<div><i style="height:'.(int)$r['nilai'].'%"><b>'.(int)$r['nilai'].'</b></i></div>';echo '</div>';}echo '</div>';}
 if($G){echo '<h3>Menu Cepat</h3><div class=grid>';foreach([['soalform','➕','Tambah Soal',1],['evaluasi','📋','Buat Evaluasi',2],['hasil','📈','Lihat Nilai',3],['laporan','📄','Cetak Laporan',4]] as $x)echo "<a class='st tile c$x[3]' href='index.php?p=$x[0]'><span>$x[1]</span>$x[2]</a>";echo '</div>';}
 else{$tot=(int)q("SELECT COUNT(*) FROM evaluasi")->fetchColumn();$dn=(int)q("SELECT COUNT(DISTINCT evaluasi_id) FROM hasil WHERE user_id=?",[$u['id']])->fetchColumn();$pc=$tot?round($dn/$tot*100):0;echo '<div class=card><b>📈 Progres Belajar</b><span style="float:right">'.$dn.' dari '.$tot.' evaluasi selesai ('.$pc.'%)</span><div class=pg style="margin-top:10px"><div style="width:'.$pc.'%"></div></div><p style="margin:12px 0 0"><a class="btn" href="index.php?p=materi">📖 Lanjut Belajar Materi</a></p></div><h3>Evaluasi Terbaru</h3><div class=card><table><tr><th>No<th>Nama Evaluasi<th>Mata Pelajaran<th>Waktu<th>Aksi</tr>';foreach(q("SELECT * FROM evaluasi ORDER BY id DESC LIMIT 5")->fetchAll() as $i=>$e)echo '<tr><td>'.($i+1).'<td>'.h($e['nama']).'<td>'.h($e['mapel']).'<td>'.$e['waktu'].' menit<td><a class="btn sm" href="index.php?p=kerja&id='.$e['id'].'">Mulai</a></tr>';echo '</table></div>';}}
if($p=='materi'){hd('Materi');if(!$G)echo '<div class="card tip">💡 <b>Cara belajar:</b> 1) Baca materi sampai selesai · 2) Kerjakan evaluasi · 3) Cek kunci jawaban dan perbaiki yang salah.</div>';if($G)echo '<div class=card><b>Tambah Materi</b><form method=post><input type=hidden name=act value=materi><input name=judul placeholder=Judul required><textarea name=isi rows=4 placeholder="Isi (boleh HTML)"></textarea><button class=btn>Simpan</button></form></div>';
 foreach(q("SELECT * FROM materi ORDER BY id")->fetchAll() as $i=>$m){$mn=max(1,round(str_word_count(strip_tags($m['isi']))/120));echo '<details class="card mat"'.($i?'':' open').'><summary><span class=num>'.($i+1).'</span><div><b>'.h($m['judul']).'</b><br><small>⏱ ±'.$mn.' menit baca</small></div></summary><div class=isi>'.$m['isi'].'<div class=cta>Sudah paham? <a class="btn g" href="index.php?p=evaluasi">Uji pemahamanmu →</a></div></div></details>';}}
if($p=='soal'&&$G){hd('Bank Soal');if(!empty($_SESSION['msg'])){echo '<div class="card hero">'.h($_SESSION['msg']).'</div>';unset($_SESSION['msg']);}
 if($G)echo '<div class="card bar"><a class=btn href="index.php?p=soalform">+ Tambah Soal</a> <a class="btn o" href="index.php?p=impor">⬆ Impor Soal</a> <span class=sp></span><a class="btn g" href="index.php?p=export&t=soal&f=xlsx">Export Excel</a> <a class=btn href="index.php?p=export&t=soal&f=docx">Export Word</a> <a class="btn r" href="index.php?p=export&t=soal&f=pdf" target=_blank>Export PDF</a></div>';
 echo '<div class=card><table><tr><th>No<th>Pertanyaan<th>Mata Pelajaran<th>Tipe'.($G?'<th>Kunci<th>Aksi':'').'</tr>';
 foreach(q("SELECT * FROM soal")->fetchAll() as $i=>$s){echo '<tr><td>'.($i+1).'<td>'.h($s['pertanyaan']).'<td>'.h($s['mapel']).'<td>Pilihan Ganda';
  if($G)echo '<td class=ok>'.$s['kunci'].'<td><a class="btn sm" href="index.php?p=soalform&id='.$s['id'].'">Edit</a> <form method=post style=display:inline onsubmit="return confirm(\'Hapus soal?\')"><input type=hidden name=act value=delsoal><input type=hidden name=id value='.$s['id'].'><button class="btn sm r">Hapus</button></form>';echo '</tr>';}
 echo '</table></div>';}
if($p=='soalform'&&$G){$s=q("SELECT * FROM soal WHERE id=?",[(int)($_GET['id']??0)])->fetch()?:['id'=>'','pertanyaan'=>'','mapel'=>'TKJ','a'=>'','b'=>'','c'=>'','d'=>'','kunci'=>'A'];
 hd(($s['id']?'Edit':'Tambah').' Soal');echo '<div class=card><form method=post><input type=hidden name=act value=soal><input type=hidden name=id value="'.$s['id'].'"><label>Pertanyaan</label><textarea name=pertanyaan rows=3 required>'.h($s['pertanyaan']).'</textarea><label>Mata Pelajaran</label><select name=mapel>';
 foreach(['TKJ','Administrasi Sistem Jaringan','Teknologi Layanan Jaringan'] as $m)echo '<option'.($m==$s['mapel']?' selected':'').'>'.$m.'</option>';
 echo '</select><label>Tipe Soal</label><select><option>Pilihan Ganda</option></select><label>Pilihan Jawaban</label>';
 foreach(['a','b','c','d'] as $o)echo '<div class=pj id=pj'.$o.'><b>'.strtoupper($o).'</b><input name='.$o.' value="'.h($s[$o]).'" required></div>';
 echo '<label>Kunci Jawaban</label><select name=kunci id=kj>';foreach(['A','B','C','D'] as $k)echo '<option'.($k==$s['kunci']?' selected':'').'>'.$k.'</option>';
 echo '</select>';if(!$s['id']){echo '<label>Masukkan ke Evaluasi</label><select name=ev><option value=0>Tidak ditambahkan</option>';foreach(q("SELECT id,nama FROM evaluasi ORDER BY id DESC")->fetchAll() as $n=>$x)echo '<option value='.$x['id'].($n?'':' selected').'>'.h($x['nama']).'</option>';echo '</select>';}
 echo '<button class="btn g">Simpan</button> <a class="btn gr" href="index.php?p=soal">Batal</a></form></div><script>function mk(){["A","B","C","D"].forEach(x=>document.getElementById("pj"+x.toLowerCase()).classList.toggle("key",x==kj.value))}kj.onchange=mk;mk()</script>';}
if($p=='impor'&&$G){hd('Impor Soal dari File');echo '<div class=card><form method=post enctype=multipart/form-data><input type=hidden name=act value=import><div class=drop><div style="font-size:38px">📤</div><b>Pilih file (Word / Excel / PDF / CSV)</b><br><small id=fn>atau drag and drop file di sini</small><input type=file name=f accept=".docx,.xlsx,.csv,.txt,.pdf" required onchange="fn.textContent=this.files[0].name"></div>
 <p><b>Contoh format file:</b></p><ul><li>Word (.docx)</li><li>Excel (.xlsx / .csv)</li><li>PDF (.pdf)</li></ul><p>Tiap baris: <code>Pertanyaan | A | B | C | D | Kunci</code> (di Excel: kolom A sampai F).</p><button class=btn>⬆ Proses Impor</button></form></div>';}
if($p=='evaluasi'){hd('Evaluasi');
 if($G){echo '<div class=card><b>Buat Evaluasi</b><form method=post><input type=hidden name=act value=evaluasi><input name=nama placeholder="Nama evaluasi" required><input type=number name=waktu value=60 placeholder="Waktu (menit)">';foreach(q("SELECT id,pertanyaan FROM soal")->fetchAll() as $s)echo '<label class=opt><input type=checkbox name=ids[] value='.$s['id'].' checked>'.h($s['pertanyaan']).'</label>';echo '<button class=btn>Simpan Evaluasi</button></form></div>';}
 echo '<div class=card><table><tr><th>No<th>Nama Evaluasi<th>Mata Pelajaran<th>Soal<th>Waktu'.($G?'':'<th>Nilai').'<th>Aksi</tr>';
 foreach(q("SELECT e.*,(SELECT COUNT(*) FROM evaluasi_soal WHERE evaluasi_id=e.id) n,(SELECT id FROM hasil WHERE evaluasi_id=e.id AND user_id=? ORDER BY id DESC LIMIT 1) hid,(SELECT nilai FROM hasil WHERE evaluasi_id=e.id AND user_id=? ORDER BY id DESC LIMIT 1) nl FROM evaluasi e",[$u['id'],$u['id']])->fetchAll() as $i=>$e){
  echo '<tr><td>'.($i+1).'<td>'.h($e['nama']).'<td>'.h($e['mapel']).'<td>'.$e['n'].'<td>'.$e['waktu'].' menit'.($G?'':'<td>'.($e['nl']!==null?'<b>'.$e['nl'].'</b>':'-')).'<td>';
  if($G)echo '<a class="btn sm" href="index.php?p=evsoal&id='.$e['id'].'">Lihat Soal &amp; Kunci</a> <form method=post style=display:inline><input type=hidden name=act value=delev><input type=hidden name=id value='.$e['id'].'><button class="btn sm r">Hapus</button></form>';
  else{echo '<a class="btn sm" href="index.php?p=kerja&id='.$e['id'].'">'.($e['hid']?'Ulangi':'Mulai').'</a>';if($e['hid'])echo ' <a class="btn sm g" href="index.php?p=detail&id='.$e['hid'].'">Soal &amp; Kunci</a>';}
  echo '</tr>';}
 echo '</table></div>';}
if($p=='evsoal'&&$G){$e=q("SELECT * FROM evaluasi WHERE id=?",[$_GET['id']??0])->fetch();if($e){hd('Soal &amp; Kunci Jawaban');echo '<div class=card><b>'.h($e['nama']).'</b> &bull; '.$e['waktu'].' menit <a class="btn sm gr" href="index.php?p=evaluasi" style="float:right">Kembali</a></div><div class=card><table><tr><th>No<th>Pertanyaan<th>Pilihan<th>Kunci</tr>';
 foreach(q("SELECT s.* FROM soal s JOIN evaluasi_soal x ON x.soal_id=s.id WHERE x.evaluasi_id=?",[$e['id']])->fetchAll() as $i=>$s)echo '<tr><td>'.($i+1).'<td>'.h($s['pertanyaan']).'<td>A. '.h($s['a']).'<br>B. '.h($s['b']).'<br>C. '.h($s['c']).'<br>D. '.h($s['d']).'<td class=ok>'.$s['kunci'].'</tr>';
 echo '</table></div><h3>Hasil Nilai</h3><div class=card><table><tr><th>No<th>Nama Murid<th>Nilai<th>Keterangan</tr>';foreach(laporan((int)$e['id'],'') as $i=>$r)echo '<tr><td>'.($i+1).'<td>'.h($r['nama']).'<td><b>'.$r['nilai'].'</b><td class='.($r['ket']=='Lulus'?'ok':'no').'>'.$r['ket'].'</tr>';echo '</table></div>';}}
if($p=='kerja'&&!$G){$e=q("SELECT * FROM evaluasi WHERE id=?",[$_GET['id']??0])->fetch();$ss=q("SELECT s.* FROM soal s JOIN evaluasi_soal x ON x.soal_id=s.id WHERE x.evaluasi_id=?",[$e['id']])->fetchAll();
 hd('Kerjakan Evaluasi');echo '<div class=card><table class=info><tr><td>Nama Evaluasi<td>: '.h($e['nama']).'<tr><td>Mata Pelajaran<td>: '.h($e['mapel']).'<tr><td>Jumlah Soal<td>: '.count($ss).'<tr><td>Waktu<td>: '.$e['waktu'].' Menit &nbsp; <span class=chip>⏱ <b id=tm></b></span></table><div class=pg><div id=pgb></div></div><small id=pgt></small></div><form method=post id=f><input type=hidden name=act value=submit><input type=hidden name=eid value='.$e['id'].'>';
 foreach($ss as $i=>$s){echo '<div class="card q" style="display:'.($i?'none':'block').'"><h3 style="margin-top:0">'.($i+1).'. '.h($s['pertanyaan']).'</h3>';foreach(['a','b','c','d'] as $o)echo '<label class=opt><input type=radio name=ans['.$s['id'].'] value='.strtoupper($o).'><b class=ol>'.strtoupper($o).'</b><span>'.h($s[$o]).'</span></label>';echo '</div>';}
 echo '<div class=card><button type=button class="btn gr" id=pv>← Sebelumnya</button><span style="float:right"><button type=button class=btn id=nx>Selanjutnya →</button><button class="btn g" id=sb style="display:none">Kirim Jawaban</button></span><div style="clear:both;margin-top:12px" id=nv></div><small>Hijau = sudah dijawab, oranye = belum</small></div></form><script>let t='.($e['waktu']*60).',c=0,Q=document.querySelectorAll(".q");
Q.forEach((x,k)=>{let b=document.createElement("button");b.type="button";b.textContent=k+1;b.style.margin="2px";b.onclick=()=>show(k);nv.appendChild(b)});
function show(i){c=i;pgb.style.width=((i+1)/Q.length*100)+"%";pgt.textContent="Soal "+(i+1)+" dari "+Q.length+" • terjawab "+document.querySelectorAll(".q input:checked").length;Q.forEach((x,k)=>x.style.display=k==i?"block":"none");pv.style.visibility=i?"visible":"hidden";nx.style.display=i==Q.length-1?"none":"inline-block";sb.style.display=i==Q.length-1?"inline-block":"none";[...nv.children].forEach((b,k)=>{b.className="btn sm "+(Q[k].querySelector("input:checked")?"g":"o");b.style.outline=k==i?"3px solid #0b2a5b":"none"})}
pv.onclick=()=>show(c-1);nx.onclick=()=>show(c+1);f.onchange=()=>show(c);show(0);
setInterval(()=>{t--;tm.textContent=Math.floor(t/60)+":"+String(t%60).padStart(2,"0");if(t<=0)f.submit()},1000)</script>';}
if($p=='hasil'){hd('Hasil / Nilai');daftar(false);}
if($p=='sertifikat'){hd('Sertifikat');daftar(true);}
if($p=='detail'){$r=q("SELECT h.*,u.nama,u.username,e.nama en,e.mapel FROM hasil h JOIN users u ON u.id=h.user_id JOIN evaluasi e ON e.id=h.evaluasi_id WHERE h.id=?",[$_GET['id']??0])->fetch();
 if($r&&($G||$r['user_id']==$u['id'])){hd('Detail Hasil &amp; Kunci Jawaban');echo '<div class=card><div class=res><div class=ring style="--v:'.$r['nilai'].'"><b>'.$r['nilai'].'</b></div><div><h3 style="margin:0 0 4px">'.($r['nilai']>=$KKM?'Selamat, kamu lulus! 🎉':'Belum lulus, ayo coba lagi 💪').'</h3><span>'.$r['benar'].' benar dari '.$r['total'].' soal. '.($r['nilai']>=$KKM?'Pertahankan semangat belajarmu!':'Pelajari lagi materinya dan perhatikan kunci jawaban di bawah.').'</span></div></div><table class=info><tr><td>Nama Murid<td>: '.h($r['nama']).'<tr><td>Nama Evaluasi<td>: '.h($r['en']).'<tr><td>Mata Pelajaran<td>: '.h($r['mapel']).'<tr><td>Tanggal<td>: '.tgl($r['tanggal']).'<tr><td>Nilai<td>: <b>'.$r['nilai'].'</b><tr><td>Jumlah Benar<td>: '.$r['benar'].' dari '.$r['total'].'</table><p>'.($G?'':'<a class="btn g" href="index.php?p=cert&id='.$r['id'].'" target=_blank>⬇ Unduh Sertifikat</a> ').'<a class="btn" href="index.php?p=materi">📖 Baca Materi Lagi</a></p></div>'.($G?'':certhtml($r)).'<div class=card><table><tr><th>No<th>Pertanyaan<th>Jawaban Murid<th>Kunci Jawaban<th>Status</tr>';
  foreach(q("SELECT s.pertanyaan,s.kunci,j.jawab FROM jawaban j JOIN soal s ON s.id=j.soal_id WHERE j.hasil_id=?",[$r['id']])->fetchAll() as $i=>$x){$b=$x['jawab']==$x['kunci'];echo '<tr><td>'.($i+1).'<td>'.h($x['pertanyaan']).'<td>'.($x['jawab']?:'-').'<td>'.$x['kunci'].'<td><span class="badge '.($b?'bo">Benar':'bn">Salah').'</span></tr>';}echo '</table></div>';}}
if($p=='murid'&&$G){hd('Data Murid');echo '<div class=card><b>📥 Impor Data Murid 1 Kelas</b><form method=post enctype=multipart/form-data><input type=hidden name=act value=murid_import><label>Nama Kelas</label><input name=kelas placeholder="Contoh: XI TKJ 1" required><div class=drop><div style="font-size:34px">📤</div><b>Choose File: pilih file daftar murid</b><br><small id=fm>Excel (.xlsx), CSV, Word (.docx), atau TXT. Satu nama per baris.</small><input type=file name=f accept=".xlsx,.csv,.txt,.docx" onchange="fm.textContent=this.files[0].name"></div><label>Atau tempel daftar nama (satu nama per baris)</label><textarea name=tempel rows=4 placeholder="Andi Pratama&#10;Budi Santoso"></textarea><button class=btn>⬆ Impor Murid</button> <a class="btn gr" href="index.php?p=templatemurid">Unduh Contoh Format (CSV)</a><p><small>Username murid = nama di file (huruf kecil), password awal 123. Sertifikat memakai nama yang dipakai saat login.</small></p></form></div><div class=card><b>⚡ Isi Cepat</b><p style="margin:6px 0"><small>Memuat 36 nama murid contoh ke kelas XI TKJ (yang sudah ada dilewati).</small></p><form method=post><input type=hidden name=act value=murid_contoh><button class="btn o">Isi 36 Murid Contoh</button></form></div><div class=card><b>Tambah Satu Murid</b><form method=post><input type=hidden name=act value=murid><input name=nama placeholder="Nama lengkap" required><input name=username placeholder="Username (password otomatis 123)" required><button class=btn>Tambah Murid</button></form></div><div class=card><b>Daftar Murid ('.q("SELECT COUNT(*) FROM users WHERE role='murid'")->fetchColumn().')</b><table><tr><th>No<th>Nama<th>Username<th>Kelas</tr>';
 foreach(q("SELECT * FROM users WHERE role='murid'")->fetchAll() as $i=>$m)echo '<tr><td>'.($i+1).'<td>'.h($m['nama']).'<td>'.h($m['username']).'<td>'.h($m['kelas']).'</tr>';echo '</table></div>';}
if($p=='laporan'&&$G){$e=(int)($_GET['e']??0);$k=$_GET['k']??'';$qs='&e='.$e.'&k='.urlencode($k);hd('Laporan Hasil Evaluasi');
 echo '<div class=card><form method=get class=flt><input type=hidden name=p value=laporan><div><label>Pilih Evaluasi</label><select name=e><option value=0>Semua Evaluasi</option>';foreach(q("SELECT id,nama FROM evaluasi")->fetchAll() as $x)echo '<option value='.$x['id'].($x['id']==$e?' selected':'').'>'.h($x['nama']).'</option>';
 echo '</select></div><div><label>Pilih Kelas</label><select name=k><option value="">Semua Kelas</option>';foreach(q("SELECT DISTINCT kelas FROM users WHERE role='murid'")->fetchAll() as $x)echo '<option'.($x['kelas']==$k?' selected':'').'>'.h($x['kelas']).'</option>';
 echo '</select></div><div><button class=btn style="margin-bottom:12px">Tampilkan</button></div></form><a class="btn g" href="index.php?p=export&t=hasil&f=xlsx'.$qs.'">Export Excel</a> <a class=btn href="index.php?p=export&t=hasil&f=docx'.$qs.'">Export Word</a> <a class="btn r" href="index.php?p=export&t=hasil&f=pdf'.$qs.'" target=_blank>Export PDF</a></div>';
 echo '<div class=card><table><tr><th>No<th>Nama Murid<th>Nilai<th>Keterangan</tr>';foreach(laporan($e,$k) as $i=>$r)echo '<tr><td>'.($i+1).'<td>'.h($r['nama']).'<td>'.$r['nilai'].'<td class='.($r['ket']=='Lulus'?'ok':'no').'>'.$r['ket'].'</tr>';echo '</table></div>';}
if($p=='pengaturan'&&$G){hd('Pengaturan');$au=(int)q("SELECT COUNT(*) FROM app_flags WHERE k='auto_daftar'")->fetchColumn();echo '<div class=card><b>👥 Pendaftaran Akun Murid</b><p>Saat ini: <b>'.($au?'akun baru dibuat otomatis saat murid login dengan nama baru':'hanya nama yang ada di Data Murid yang bisa login').'</b></p><form method=post><input type=hidden name=act value=set_auto><input type=hidden name=v value='.($au?0:1).'><button class="btn '.($au?'r':'g').'">'.($au?'Matikan daftar otomatis':'Izinkan daftar otomatis').'</button></form></div><div class=card><p>Nilai minimal lulus (KKM): <b>'.$KKM.'</b></p><form method=post onsubmit="return confirm(\'Hapus semua hasil nilai?\')"><input type=hidden name=act value=reset><button class="btn r">Reset Semua Hasil Nilai</button></form></div>';}
if($p=='profil'){hd('Profil');echo '<div class=card><table class=info><tr><td>Nama<td>: '.h($u['nama']).'<tr><td>Username<td>: '.h($u['username']).'<tr><td>Kelas<td>: '.h($u['kelas']).'<tr><td>Peran<td>: '.h($u['role']).'</table></div>';}
if($p=='lkpd'){hd('LKPD');
 if($G)echo '<div class=card><b>Tambah LKPD</b><form method=post><input type=hidden name=act value=lkpd_add><input name=judul placeholder="Judul LKPD" required><textarea name=tujuan rows=2 placeholder="Tujuan pembelajaran"></textarea><textarea name=petunjuk rows=2 placeholder="Petunjuk pengerjaan"></textarea><textarea name=tugas rows=5 placeholder="Langkah kerja / pertanyaan (satu baris per nomor)" required></textarea><button class=btn>Simpan LKPD</button></form></div>';
 echo '<div class=card><table><tr><th>No<th>Judul LKPD<th>'.($G?'Terkumpul':'Status').'<th>Aksi</tr>';
 foreach(q("SELECT l.*,(SELECT COUNT(*) FROM lkpd_jawab WHERE lkpd_id=l.id) n,(SELECT nilai FROM lkpd_jawab WHERE lkpd_id=l.id AND user_id=?) nl,(SELECT COUNT(*) FROM lkpd_jawab WHERE lkpd_id=l.id AND user_id=?) sd FROM lkpd l ORDER BY l.id",[$u['id'],$u['id']])->fetchAll() as $i=>$l){
  echo '<tr><td>'.($i+1).'<td>'.h($l['judul']).'<td>'.($G?$l['n'].' murid':($l['sd']?($l['nl']!==null?'<span class="badge bo">Dinilai: '.$l['nl'].'</span>':'<span class="badge bo">Terkirim</span>'):'<span class="badge bn">Belum dikerjakan</span>')).'<td><a class="btn sm" href="index.php?p=lkpdbuka&id='.$l['id'].'">'.($G?'Lihat Jawaban':($l['sd']?'Lihat':'Kerjakan')).'</a>';
  if($G)echo ' <form method=post style=display:inline onsubmit="return confirm(\'Hapus LKPD?\')"><input type=hidden name=act value=lkpd_del><input type=hidden name=id value='.$l['id'].'><button class="btn sm r">Hapus</button></form>';echo '</tr>';}
 echo '</table></div>';}
if($p=='lkpdbuka'){$l=q("SELECT * FROM lkpd WHERE id=?",[$_GET['id']??0])->fetch();if($l){hd('LKPD');
 echo '<div class=card><h3 style="margin-top:0">'.h($l['judul']).'</h3><p><b>🎯 Tujuan</b><br>'.nl2br(h($l['tujuan'])).'</p><p><b>📋 Petunjuk</b><br>'.nl2br(h($l['petunjuk'])).'</p><p><b>📝 Langkah Kerja / Pertanyaan</b><br>'.nl2br(h($l['tugas'])).'</p></div>';
 if(!$G){$j=q("SELECT * FROM lkpd_jawab WHERE lkpd_id=? AND user_id=?",[$l['id'],$u['id']])->fetch();
  echo '<div class=card><form method=post><input type=hidden name=act value=lkpd_kirim><input type=hidden name=lid value='.$l['id'].'><b>Jawaban / Hasil Pengamatan Kamu</b><textarea name=jawaban rows=10 required placeholder="Tulis jawaban sesuai nomor soal...">'.h($j['jawaban']??'').'</textarea><button class="btn g">'.($j?'Kirim Ulang':'Kirim Jawaban').'</button></form>';
  if($j&&$j['nilai']!==null)echo '<p class=ok>Nilai: '.$j['nilai'].'</p><p>Catatan guru: '.nl2br(h($j['catatan'])).'</p>';echo '</div>';}
 else{echo '<div class=card><b>Jawaban Murid</b><table><tr><th>Murid<th>Jawaban<th>Nilai &amp; Catatan</tr>';
  foreach(q("SELECT j.*,u.nama FROM lkpd_jawab j JOIN users u ON u.id=j.user_id WHERE j.lkpd_id=? ORDER BY j.tanggal DESC",[$l['id']])->fetchAll() as $j)echo '<tr><td>'.h($j['nama']).'<td>'.nl2br(h($j['jawaban'])).'<td><form method=post><input type=hidden name=act value=lkpd_nilai><input type=hidden name=id value='.$j['id'].'><input type=hidden name=lid value='.$l['id'].'><input type=number name=nilai min=0 max=100 placeholder=Nilai value="'.h($j['nilai']).'"><input name=catatan placeholder="Catatan" value="'.h($j['catatan']).'"><button class="btn sm g">Simpan</button></form></tr>';echo '</table></div>';}
 echo '<p><a class="btn gr" href="index.php?p=lkpd">← Kembali</a></p>';}}
if($p=='digital'){hd('Pojok Digital');?>
<div class=pjh><b>POJOK DIGITAL</b><span>Lihat Dunianya, Baca Kisahnya, Pahami Datanya!</span></div>
<div class=card>
<div class=thd><div><b style="font-size:18px">📚 Pilih Topik Web Server</b><br><small>Tekan sebuah tombol untuk membuka materinya.</small></div><div class=tprog><span id=tcount>0 dari 9 topik sudah dibaca</span><div class=pg><div id=tbar style="width:0%"></div></div></div></div>
<div class=tgrid>
<button type=button class="tcard t1" onclick="topik(0)"><span class=ti>🌐</span><b>Pengertian</b><small>Apa itu web server?</small><i class=ck>✓</i></button>
<button type=button class="tcard t2" onclick="topik(1)"><span class=ti>⚙️</span><b>Fungsi</b><small>Tugas-tugas web server</small><i class=ck>✓</i></button>
<button type=button class="tcard t3" onclick="topik(2)"><span class=ti>🔄</span><b>Cara Kerja</b><small>Dari ketik alamat sampai halaman tampil</small><i class=ck>✓</i></button>
<button type=button class="tcard t4" onclick="topik(3)"><span class=ti>👍</span><b>Kelebihan</b><small>Mengapa web server berguna</small><i class=ck>✓</i></button>
<button type=button class="tcard t5" onclick="topik(4)"><span class=ti>⚠️</span><b>Kekurangan</b><small>Masalah dan solusinya</small><i class=ck>✓</i></button>
<button type=button class="tcard t6" onclick="topik(5)"><span class=ti>🧩</span><b>Jenis dan Contoh</b><small>Apache, Nginx, IIS, LiteSpeed</small><i class=ck>✓</i></button>
<button type=button class="tcard t7" onclick="topik(6)"><span class=ti>🔌</span><b>Alamat dan Port</b><small>URL, HTTP, HTTPS</small><i class=ck>✓</i></button>
<button type=button class="tcard t8" onclick="topik(7)"><span class=ti>🔐</span><b>Keamanan Dasar</b><small>Menjaga server tetap aman</small><i class=ck>✓</i></button>
<button type=button class="tcard t9" onclick="topik(8)"><span class=ti>🛠️</span><b>Praktik XAMPP</b><small>Menjalankan web server sendiri</small><i class=ck>✓</i></button>
</div></div>

<div id=tpanel class=card style="display:none">
<div class=tbar2><button type=button class="btn sm gr" onclick="tutup()">← Semua Topik</button><b id=ttitle></b></div>

<div class=tp><h3>🌐 Pengertian Web Server</h3>
<p>Web server adalah <b>perangkat lunak</b> yang bertugas menerima permintaan (<i>request</i>) dari browser, lalu mengirimkan kembali halaman web yang diminta (<i>response</i>). Istilah web server juga dipakai untuk komputer tempat perangkat lunak itu berjalan.</p>
<p>Contoh perangkat lunak web server: <b>Apache</b>, <b>Nginx</b>, dan <b>IIS</b>. Di kelas, Apache dijalankan lewat XAMPP di komputer lab.</p>
<div class=qbox><b>🍽️ Analogi sederhana</b><br>Bayangkan restoran: browser adalah pelanggan yang memesan, web server adalah pelayan yang menerima pesanan dan mengantarkan makanannya, yaitu halaman web.</div>
<div class=ing><b>Ingat!</b> Web server menyimpan dan mengirim file website. Browser yang menampilkannya kepada kita.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Apa bedanya browser dan web server?<br><b>Jawaban:</b> Browser (client) meminta dan menampilkan halaman. Web server menerima permintaan itu dan mengirim halaman yang diminta.</div></details></div>

<div class=tp><h3>⚙️ Fungsi Web Server</h3>
<ul><li><b>Menerima dan menjawab permintaan</b> HTTP dari banyak client sekaligus.</li><li><b>Menyimpan dan menyajikan file website</b> (HTML, CSS, JavaScript, gambar) dari folder DocumentRoot, yaitu <code>htdocs</code> pada XAMPP.</li><li><b>Menjalankan skrip sisi server</b> seperti PHP dan terhubung ke database MySQL.</li><li><b>Mencatat aktivitas dan kesalahan</b> pada file log.</li><li><b>Mengatur hak akses dan keamanan</b> pengguna.</li><li><b>Melayani beberapa website sekaligus</b> lewat fitur virtual host.</li></ul>
<div class=qbox><b>💻 Contoh nyata</b><br>Saat kamu membuka LMS ini, Apache menjalankan <code>index.php</code>, PHP mengambil data dari MySQL, lalu hasilnya dikirim ke browser sebagai halaman web.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Sebutkan tiga fungsi web server.<br><b>Jawaban contoh:</b> menerima permintaan dari browser, menyimpan dan menyajikan file website, serta menjalankan skrip PHP dan terhubung ke database.</div></details></div>

<div class=tp><h3>🔄 Cara Kerja Web Server</h3>
<div class=flow><div><b>1. Ketik alamat</b>Kamu mengetik URL atau menekan tautan di browser.</div><div><b>2. Cari server</b>Browser mencari alamat IP server lewat DNS (pada localhost langsung ke 127.0.0.1).</div><div><b>3. Kirim request</b>Browser mengirim permintaan HTTP ke web server (port 80 atau 443).</div><div><b>4. Proses</b>Web server mencari file, menjalankan PHP, dan mengambil data dari database bila perlu.</div><div><b>5. Kirim response</b>Web server mengirim kode status dan isi halaman, lalu browser menampilkannya.</div></div>
<div class=ing><b>Ingat!</b> Kode status <b>200</b> berarti berhasil, <b>404</b> berarti halaman tidak ditemukan, dan <b>500</b> berarti ada kesalahan di server.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Kode status apa yang muncul jika halaman tidak ditemukan?<br><b>Jawaban:</b> 404 Not Found.</div></details></div>

<div class=tp><h3>👍 Kelebihan Web Server</h3>
<ul><li><b>Diakses banyak orang sekaligus</b>, kapan saja, lewat jaringan atau internet.</li><li><b>Konten terpusat:</b> satu kali pembaruan langsung dilihat semua pengguna.</li><li><b>Mendukung aplikasi dinamis</b> seperti PHP, database, dan LMS.</li><li><b>Banyak pilihan gratis dan open source</b>, misalnya Apache dan Nginx.</li><li><b>Dapat diatur sesuai kebutuhan</b>: keamanan, tampilan, dan jumlah website.</li></ul>
<div class=qbox><b>🏫 Contoh</b><br>Materi sekolah ditaruh di satu web server, lalu siswa membukanya dari laptop atau HP tanpa perlu saling mengirim file.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Mengapa konten yang terpusat menguntungkan?<br><b>Jawaban:</b> Perubahan cukup dilakukan sekali di server, dan semua pengguna langsung melihat versi terbaru.</div></details></div>

<div class=tp><h3>⚠️ Kekurangan Web Server dan Solusinya</h3>
<div style="overflow-x:auto"><table><tr><th>Kekurangan<th>Cara mengatasi</tr>
<tr><td>Butuh biaya perangkat, listrik, dan perawatan<td>Merencanakan anggaran atau menyewa layanan hosting</tr>
<tr><td>Rentan serangan (misalnya DDoS dan SQL injection)<td>Memperbarui perangkat lunak, memakai firewall, memeriksa input pengguna</tr>
<tr><td>Perlu administrator yang paham konfigurasi<td>Pelatihan dan dokumentasi yang jelas</tr>
<tr><td>Jika server mati, semua layanan ikut mati<td>Pemantauan, cadangan data, dan server cadangan</tr>
<tr><td>Melambat saat pengunjung terlalu banyak<td>Mengecilkan gambar, memakai cache, menambah kapasitas</tr></table></div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Sebutkan satu kekurangan web server beserta cara mengatasinya.<br><b>Jawaban contoh:</b> server bisa mati sehingga layanan berhenti. Solusinya membuat jadwal pengecekan dan salinan cadangan.</div></details></div>

<div class=tp><h3>🧩 Jenis dan Contoh Web Server</h3>
<div style="overflow-x:auto"><table><tr><th>Web server<th>Ciri singkat</tr>
<tr><td><b>Apache HTTP Server</b><td>Open source, banyak dipakai dan mudah dipelajari. Menjadi bagian dari paket XAMPP.</tr>
<tr><td><b>Nginx</b><td>Open source, dikenal ringan dan efisien untuk melayani banyak koneksi.</tr>
<tr><td><b>Microsoft IIS</b><td>Web server dari Microsoft untuk Windows Server.</tr>
<tr><td><b>LiteSpeed</b><td>Tersedia edisi berbayar dan edisi terbuka (OpenLiteSpeed).</tr></table></div>
<div class=ing><b>Ingat!</b> Apa pun jenisnya, tugas dasarnya sama: menerima request dan mengirim response.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Web server apa yang kita pakai pada XAMPP?<br><b>Jawaban:</b> Apache.</div></details></div>

<div class=tp><h3>🔌 Alamat dan Port</h3>
<div class=url><span class=u1>https://</span><span class=u2>www.contoh.com</span><span class=u3>:443</span><span class=u4>/materi/web.html</span></div>
<ul><li><b style="color:#0d7f82">https://</b> : protokol yang dipakai.</li><li><b style="color:#b7791f">www.contoh.com</b> : nama domain (diterjemahkan DNS menjadi alamat IP).</li><li><b style="color:#c0494c">:443</b> : port, yaitu pintu layanan pada server.</li><li><b style="color:#3b6fd6">/materi/web.html</b> : letak file yang diminta.</li></ul>
<div style="overflow-x:auto"><table><tr><th>Protokol<th>Port bawaan<th>Keterangan</tr><tr><td>HTTP<td>80<td>Tanpa enkripsi</tr><tr><td>HTTPS<td>443<td>Terenkripsi dengan SSL/TLS</tr></table></div>
<div class=qbox><b>🏠 Tahukah kamu?</b> <code>localhost</code> (alamat 127.0.0.1) selalu menunjuk ke komputer kita sendiri. Karena itu kita bisa menguji web server tanpa internet.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Mengapa halaman login sebaiknya memakai HTTPS?<br><b>Jawaban:</b> Data yang dikirim dienkripsi sehingga password lebih sulit dicuri.</div></details></div>

<div class=tp><h3>🔐 Keamanan Dasar Web Server</h3>
<ul><li><b>Gunakan HTTPS</b> agar data terenkripsi.</li><li><b>Perbarui perangkat lunak</b> secara rutin untuk menutup celah keamanan.</li><li><b>Batasi hak akses</b> dan pakai password yang kuat.</li><li><b>Buat cadangan (backup)</b> website dan database secara berkala.</li><li><b>Aktifkan firewall</b> dan matikan layanan yang tidak dipakai.</li></ul>
<div class=ing><b>Ingat!</b> Pengaturan bawaan XAMPP (misalnya password root MySQL kosong) hanya cocok untuk belajar di komputer sendiri, bukan untuk server yang dibuka ke publik.</div>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Mengapa pengaturan bawaan XAMPP tidak aman untuk server publik?<br><b>Jawaban:</b> Karena dibuat untuk belajar: password root kosong dan pengamanan minimal, sehingga mudah diserang bila dibuka ke internet.</div></details></div>

<div class=tp><h3>🛠️ Praktik Web Server dengan XAMPP</h3>
<ol><li>Buka <b>XAMPP Control Panel</b>, lalu klik <b>Start</b> pada Apache (dan MySQL bila perlu).</li><li>Simpan folder website di <code>C:\xampp\htdocs\</code>.</li><li>Buka browser dan ketik <code>http://localhost/namafolder/</code>.</li><li>Jika muncul <b>404 Not Found</b>, periksa nama folder dan letak file <code>index.php</code>.</li><li>Jika Apache gagal start, kemungkinan port 80 dipakai aplikasi lain. Tutup aplikasi itu atau ganti port Apache.</li><li>Lihat catatan kesalahan di <code>C:\xampp\apache\logs\error.log</code>.</li></ol>
<details class=pb><summary class="btn sm">Cek Pemahaman</summary><div><b>Soal:</b> Jika muncul 404 Not Found di localhost, apa yang diperiksa lebih dulu?<br><b>Jawaban:</b> Nama folder dan letak file di dalam htdocs, juga ejaan alamat yang diketik.</div></details></div>

<div class=snav><button type=button class="btn gr" onclick="topik((tcur+TP.length-1)%TP.length)">← Topik Sebelumnya</button><button type=button class=btn onclick="topik((tcur+1)%TP.length)">Topik Berikutnya →</button></div>
</div>
<script>
var TP=document.querySelectorAll("#tpanel .tp"),TC=document.querySelectorAll(".tcard"),TT=["Pengertian","Fungsi","Cara Kerja","Kelebihan","Kekurangan","Jenis dan Contoh","Alamat dan Port","Keamanan Dasar","Praktik XAMPP"],tcur=-1,seenT={};
try{seenT=JSON.parse(localStorage.pjSeen||"{}")}catch(e){seenT={}}
function hitungT(){var n=Object.keys(seenT).length;document.getElementById("tcount").textContent=n+" dari "+TP.length+" topik sudah dibaca";document.getElementById("tbar").style.width=(n/TP.length*100)+"%";TC.forEach(function(c,k){c.classList.toggle("seen",!!seenT[k])})}
function topik(i){tcur=i;var p=document.getElementById("tpanel");p.style.display="block";TP.forEach(function(e,k){e.style.display=k==i?"block":"none"});TC.forEach(function(c,k){c.classList.toggle("on",k==i)});document.getElementById("ttitle").textContent="Topik "+(i+1)+" dari "+TP.length+": "+TT[i];seenT[i]=1;try{localStorage.pjSeen=JSON.stringify(seenT)}catch(e){}hitungT();p.scrollIntoView({behavior:"smooth",block:"start"})}
function tutup(){document.getElementById("tpanel").style.display="none";TC.forEach(function(c){c.classList.remove("on")});tcur=-1;window.scrollTo({top:0,behavior:"smooth"})}
hitungT();
</script>
<details class="card misi"><summary><b>🎯 Misi Belajar: Amati, Baca, Pahami Data, Jawab, Refleksi</b> <small>(cerita dan data simulasi)</small></summary>
<div class=sbar><button type=button class="sb on" onclick="go(0)"><i>1</i>Amati</button><button type=button class=sb onclick="go(1)"><i>2</i>Baca</button><button type=button class=sb onclick="go(2)"><i>3</i>Pahami Data</button><button type=button class=sb onclick="go(3)"><i>4</i>Jawab</button><button type=button class=sb onclick="go(4)"><i>5</i>Refleksi</button></div>

<section class="stp on">
<h3>1. Amati Gambarnya</h3>
<svg viewBox="0 0 720 300" role="img" aria-label="Diagram: tiga perangkat client terhubung lewat jaringan sekolah ke satu web server" style="width:100%;height:auto;max-width:780px;display:block;margin:auto;border-radius:16px">
<rect width="720" height="300" fill="#eef1f5"/>
<g stroke="#4b5361" stroke-width="2.5" fill="#fff"><rect x="30" y="30" width="130" height="58" rx="10"/><rect x="30" y="121" width="130" height="58" rx="10"/><rect x="30" y="212" width="130" height="58" rx="10"/></g>
<g font-family="Arial,sans-serif" font-size="15" fill="#232833" text-anchor="middle"><text x="95" y="64">Laptop siswa</text><text x="95" y="155">HP siswa</text><text x="95" y="246">PC lab</text></g>
<g stroke="#4b5361" stroke-width="2.5"><path d="M160 59H300M160 150H300M160 241H300"/><path d="M390 150H520"/></g>
<rect x="300" y="105" width="90" height="90" rx="12" fill="#cfd5de" stroke="#4b5361" stroke-width="2.5"/>
<text x="345" y="146" font-family="Arial,sans-serif" font-size="15" fill="#232833" text-anchor="middle">Jaringan</text><text x="345" y="166" font-family="Arial,sans-serif" font-size="15" fill="#232833" text-anchor="middle">sekolah</text>
<g stroke="#4b5361" stroke-width="2.5"><rect x="520" y="45" width="170" height="210" rx="14" fill="#fff"/></g>
<g fill="#dfe4ea" stroke="#4b5361" stroke-width="1.5"><rect x="535" y="62" width="140" height="30" rx="6"/><rect x="535" y="102" width="140" height="30" rx="6"/><rect x="535" y="142" width="140" height="30" rx="6"/></g>
<g fill="#0d7f82"><circle cx="550" cy="77" r="5"/><circle cx="550" cy="117" r="5"/><circle cx="550" cy="157" r="5"/></g>
<text x="605" y="205" font-family="Arial,sans-serif" font-size="15" fill="#232833" text-anchor="middle" font-weight="bold">Web Server</text><text x="605" y="226" font-family="Arial,sans-serif" font-size="13" fill="#232833" text-anchor="middle">Apache + file website</text>
<text x="458" y="140" font-family="Arial,sans-serif" font-size="12" fill="#232833" text-anchor="middle">permintaan →</text><text x="455" y="172" font-family="Arial,sans-serif" font-size="12" fill="#232833" text-anchor="middle">← halaman web</text>
<g fill="#0d7f82" stroke="#fff" stroke-width="2"><circle cx="690" cy="45" r="15"/><circle cx="345" cy="95" r="15"/><circle cx="30" cy="30" r="15"/></g>
<g font-family="Arial,sans-serif" font-size="16" font-weight="bold" fill="#fff" text-anchor="middle"><text x="690" y="51">1</text><text x="345" y="101">2</text><text x="30" y="36">3</text></g>
</svg>
<p><b>Gambar 1. Web server sekolah di ruang lab TKJ.</b><br><small>Ilustrasi buatan untuk pembelajaran, bukan foto kejadian sebenarnya.</small></p>
<p>Penanda: <b>①</b> Web server (menyimpan dan mengirim halaman web) &nbsp; <b>②</b> Jaringan sekolah (penghubung client dan server) &nbsp; <b>③</b> Perangkat client yang memakai browser.</p>
<div class=qbox><b>Pertanyaan pengamatan</b><ol><li>Apa yang kamu lihat pada gambar?</li><li>Bagaimana hubungan gambar ini dengan materi web server yang kita pelajari (pengertian, fungsi, kelebihan, dan kekurangan)?</li></ol></div>
</section>

<section class=stp>
<h3>2. Baca Kisahnya</h3>
<p><span class=tag>Cerita ilustrasi (fiksi) untuk pembelajaran, bukan kisah nyata</span></p>
<p class=story>Rani, siswa kelas XI TKJ, sering melihat teman-temannya kesulitan mencari materi yang tersebar di banyak grup chat. Bersama timnya, ia memasang Apache melalui XAMPP di komputer lab, lalu menaruh materi di folder htdocs agar bisa dibuka lewat browser di jaringan sekolah. Hari pertama berjalan lancar. Namun, ketika 30 siswa membuka halaman bersamaan, halaman terasa lambat. Rani tidak menyerah. Ia membaca log Apache dan mencatat waktu muat setiap halaman. Ternyata gambar berukuran besar membuat halaman berat. Setelah gambar dikompres, waktu muat turun jauh. Tim juga menyadari kelemahan web server: jika komputer server mati, semua layanan ikut mati, sehingga mereka membuat jadwal pengecekan dan salinan cadangan. Dari pengalaman ini Rani belajar bahwa teknologi yang baik lahir dari ketekunan, ketelitian membaca data, dan kejujuran melaporkan masalah.</p>
<div class=qbox><b>💡 Hubungannya dengan Pelajaran Kita</b><ul><li><b>Pengertian:</b> web server adalah perangkat lunak yang menerima permintaan dari browser dan mengirim halaman web. Pada cerita, itu adalah Apache di XAMPP.</li><li><b>Fungsi:</b> menyimpan dan menyajikan file website (folder htdocs) kepada banyak client lewat HTTP.</li><li><b>Kelebihan:</b> materi dapat diakses banyak orang sekaligus lewat jaringan sekolah.</li><li><b>Kekurangan:</b> halaman melambat saat pengunjung banyak, dan bila server mati semua layanan ikut mati.</li></ul></div>
</section>

<section class=stp>
<h3>3. Pahami Datanya</h3>
<p><span class=tag>Data simulasi untuk pembelajaran</span> Pengujian saat 30 pengguna membuka halaman bersamaan.</p>
<div style="overflow-x:auto"><table><tr><th>Halaman<th>Ukuran sebelum (MB)<th>Ukuran sesudah (MB)<th>Waktu muat sebelum (detik)<th>Waktu muat sesudah (detik)</tr>
<tr><td>Beranda<td>4,0<td>1,0<td>8<td>2</tr><tr><td>Materi<td>6,0<td>1,5<td>12<td>3</tr><tr><td>LKPD<td>2,0<td>0,8<td>5<td>2</tr><tr><td>Galeri<td>9,0<td>2,0<td>18<td>4</tr><tr><td>Evaluasi<td>1,0<td>0,5<td>3<td>2</tr></table></div>
<h4>Grafik waktu muat (detik, skala 0 sampai 18)</h4>
<div class=lg><span class=sw1></span> Sebelum kompresi (bergaris) &nbsp; <span class=sw2></span> Sesudah kompresi (penuh)</div>
<div class=cr><b>Beranda</b><div class=bt2><div class=trk><i class=b1 style="width:44.4%"></i></div><em>8 detik sebelum</em></div><div class=bt2><div class=trk><i class=b2 style="width:11.1%"></i></div><em>2 detik sesudah</em></div></div>
<div class=cr><b>Materi</b><div class=bt2><div class=trk><i class=b1 style="width:66.7%"></i></div><em>12 detik sebelum</em></div><div class=bt2><div class=trk><i class=b2 style="width:16.7%"></i></div><em>3 detik sesudah</em></div></div>
<div class=cr><b>LKPD</b><div class=bt2><div class=trk><i class=b1 style="width:27.8%"></i></div><em>5 detik sebelum</em></div><div class=bt2><div class=trk><i class=b2 style="width:11.1%"></i></div><em>2 detik sesudah</em></div></div>
<div class=cr><b>Galeri</b><div class=bt2><div class=trk><i class=b1 style="width:100%"></i></div><em>18 detik sebelum</em></div><div class=bt2><div class=trk><i class=b2 style="width:22.2%"></i></div><em>4 detik sesudah</em></div></div>
<div class=cr><b>Evaluasi</b><div class=bt2><div class=trk><i class=b1 style="width:16.7%"></i></div><em>3 detik sebelum</em></div><div class=bt2><div class=trk><i class=b2 style="width:11.1%"></i></div><em>2 detik sesudah</em></div></div>
<p><small>Satuan: ukuran dalam megabyte (MB), waktu dalam detik. MB = ukuran file yang harus diunduh browser.</small></p>
</section>

<section class=stp>
<h3>4. Ayo Temukan Makna</h3>
<p><small>Jawab dulu di bukumu atau berdiskusi dengan teman, baru buka pembahasan. Kolom di bawah ini tidak disimpan.</small></p>
<div class=qbox><b>Soal 1 (menemukan informasi)</b><p>Dari gambar dan cerita, perangkat apa yang menjadi web server dan perangkat apa yang menjadi client?</p><textarea rows=2 placeholder="Tulis jawabanmu..."></textarea><details class=pb><summary class="btn sm">Lihat Pembahasan</summary><div>Web server adalah komputer lab yang menjalankan Apache (XAMPP), ditandai ① pada gambar. Client adalah laptop, HP, dan PC siswa yang memakai browser (③). Keduanya dihubungkan oleh jaringan sekolah (②).</div></details></div>
<div class=qbox><b>Soal 2 (menyimpulkan hubungan)</b><p>Mengapa halaman menjadi lambat saat 30 siswa membuka bersamaan? Hubungkan gambar, cerita, dan data.</p><textarea rows=2 placeholder="Tulis jawabanmu..."></textarea><details class=pb><summary class="btn sm">Lihat Pembahasan</summary><div>Banyak permintaan HTTP masuk ke satu web server (gambar dan cerita). Halaman yang berukuran besar memperberat pekerjaan server, misalnya Galeri 9,0 MB dengan waktu muat 18 detik. Setelah gambar dikompres menjadi 2,0 MB, waktu muat turun menjadi 4 detik.</div></details></div>
<div class=qbox><b>Soal 3 (menghitung dan membandingkan)</b><p>Hitung penurunan waktu muat halaman Materi dan Galeri dalam detik dan persen. Halaman mana yang penurunannya paling besar?</p><textarea rows=2 placeholder="Tulis jawabanmu..."></textarea><details class=pb><summary class="btn sm">Lihat Pembahasan</summary><div>Materi: 12 - 3 = 9 detik, yaitu 9 ÷ 12 × 100% = 75%. Galeri: 18 - 4 = 14 detik, yaitu 14 ÷ 18 × 100% ≈ 77,8%. Galeri memiliki penurunan terbesar, baik dalam detik maupun persen.</div></details></div>
<div class=qbox><b>Soal 4 (mengambil keputusan)</b><p>Tim hanya sempat mengompres dua halaman lebih dulu. Halaman mana yang kamu pilih? Jelaskan alasanmu dengan data.</p><textarea rows=2 placeholder="Tulis jawabanmu..."></textarea><details class=pb><summary class="btn sm">Lihat Pembahasan</summary><div>Berdasarkan data, Galeri (turun 14 detik) dan Materi (turun 9 detik) memberi perbaikan terbesar. Jawaban lain bisa diterima jika alasan dan buktinya jelas, misalnya memilih Beranda karena halaman pertama yang dibuka semua pengguna.</div></details></div>
</section>

<section class=stp>
<h3>5. Inspirasi untukku</h3>
<div class=qbox><b>Refleksi</b><p>Setelah membaca, mengamati, dan memahami data, keterampilan apa yang ingin kamu kuasai?</p>
<label class=opt><input type=checkbox><span>Mengelola web server (Apache/XAMPP)</span></label><label class=opt><input type=checkbox><span>Membaca log dan mencari penyebab masalah</span></label><label class=opt><input type=checkbox><span>Mengoptimalkan kecepatan website</span></label><label class=opt><input type=checkbox><span>Menjaga keamanan server</span></label><label class=opt><input type=checkbox><span>Membuat dan mengelola website</span></label>
<textarea rows=2 placeholder="Tuliskan alasanmu (tidak disimpan)..."></textarea></div>
<div class=qbox><b>🎯 Tantangan kecil</b><p>Buka halaman Beranda, Materi, dan LKPD di LMS ini. Tekan F12, pilih tab <b>Network</b>, lalu muat ulang halaman (Ctrl+R). Catat ukuran dan waktu muat ketiga halaman. Mana yang paling berat? Tuliskan satu cara untuk memperkecilnya.</p></div>
</section>

<div class=snav><button type=button id=kb class="btn gr" onclick="go(cur-1)">← Kembali</button><span><button type=button id=lj class=btn onclick="go(cur+1)">Lanjut →</button> <a class="btn o" href="index.php">Menu Utama</a></span></div>
</details>
<details class="card tools"><summary><b>🧰 Alat Bantu: Kode Status HTTP, Perintah, dan Kamus</b></summary>
<div class=cols2><div class=card><h3 style="margin-top:0">📡 Kode Status HTTP</h3><input id=cs placeholder="Cari kode atau arti, misalnya: 404" oninput="kode()"><div id=kode></div></div>
<div class=card><h3 style="margin-top:0">⌨ Perintah dan Alamat Uji Web Server (klik Salin)</h3><div id=cmds></div></div></div>
<div class=card><h3 style="margin-top:0">📖 Kamus Istilah Web Server</h3><input id=cari placeholder="Cari istilah, misalnya: DocumentRoot" oninput="kamus()"><div id=kamus></div></div>
<div class=card><h3 style="margin-top:0">🔗 Tautan Belajar</h3><div class=lnks><a class=btn target=_blank rel=noopener href="https://httpd.apache.org/docs/">Dokumentasi Apache</a><a class=btn target=_blank rel=noopener href="https://nginx.org/en/docs/">Dokumentasi Nginx</a><a class=btn target=_blank rel=noopener href="https://www.apachefriends.org/">XAMPP</a><a class=btn target=_blank rel=noopener href="https://developer.mozilla.org/id/docs/Web/HTTP">MDN: HTTP</a></div></div>
<script>
var S=[["200 OK","Permintaan berhasil, halaman dikirim."],["301 Moved Permanently","Halaman dipindah permanen ke alamat lain."],["302 Found","Halaman dipindah sementara."],["304 Not Modified","Isi tidak berubah, browser memakai salinan (cache)."],["400 Bad Request","Permintaan dari browser tidak dapat dipahami server."],["401 Unauthorized","Perlu login atau otentikasi."],["403 Forbidden","Server menolak akses ke halaman ini."],["404 Not Found","Halaman atau file tidak ditemukan."],["500 Internal Server Error","Terjadi kesalahan di sisi server, misalnya error pada skrip PHP."],["502 Bad Gateway","Server menerima respons tidak valid dari server lain."],["503 Service Unavailable","Server sedang sibuk atau dalam perawatan."]];
function kode(){var q=document.getElementById("cs").value.toLowerCase(),o="";S.forEach(function(x){if((x[0]+" "+x[1]).toLowerCase().indexOf(q)>-1)o+="<div class=gl><b>"+x[0]+"</b><br><span>"+x[1]+"</span></div>"});document.getElementById("kode").innerHTML=o||"<p class=mut>Kode tidak ditemukan.</p>"}kode();
var C=[["Uji web server dari terminal","curl -I http://localhost"],["Alamat uji lokal di browser","http://localhost/"],["Alamat IP lokal","http://127.0.0.1/"],["Folder file website (XAMPP)","C:\\xampp\\htdocs"],["File log error Apache (XAMPP)","C:\\xampp\\apache\\logs\\error.log"],["File log akses Apache (XAMPP)","C:\\xampp\\apache\\logs\\access.log"],["Cek program yang memakai port 80","netstat -ano | findstr :80"],["Cek versi Apache (XAMPP)","C:\\xampp\\apache\\bin\\httpd.exe -v"]];
var cm=document.getElementById("cmds");C.forEach(function(x){var d=document.createElement("div");d.innerHTML="<small>"+x[0]+"</small>";var r=document.createElement("div");r.className="cmd";var c=document.createElement("code");c.textContent=x[1];var b=document.createElement("button");b.type="button";b.className="btn sm";b.textContent="Salin";b.onclick=function(){if(navigator.clipboard)navigator.clipboard.writeText(x[1]);b.textContent="Tersalin ✓";setTimeout(function(){b.textContent="Salin"},1200)};r.appendChild(c);r.appendChild(b);d.appendChild(r);cm.appendChild(d)});
var K=[["Web Server","Perangkat lunak yang menerima permintaan HTTP dan mengirim halaman web ke browser."],["Client-Server","Model komunikasi: client (browser) meminta, server melayani."],["HTTP","Protokol komunikasi browser dan web server (port 80)."],["HTTPS","HTTP yang dienkripsi dengan SSL/TLS (port 443)."],["Port","Nomor pintu layanan pada komputer, misalnya 80 untuk web."],["URL","Alamat lengkap sebuah halaman, contoh http://localhost/lms_tkj/."],["Localhost","Nama untuk komputer sendiri (alamat 127.0.0.1)."],["DocumentRoot","Folder tempat file website disimpan (pada XAMPP: htdocs)."],["Apache","Web server open source yang banyak dipakai; bagian dari XAMPP."],["Nginx","Web server ringan yang cepat untuk banyak pengunjung."],["Virtual Host","Fitur agar satu web server melayani banyak website."],["Domain & DNS","Nama website dan layanan yang menerjemahkannya menjadi alamat IP."],["SSL/TLS","Teknologi enkripsi agar data antara browser dan server aman."],["Log","Catatan aktivitas dan kesalahan web server."],["Hosting","Layanan menyewa web server agar website bisa diakses dari internet."]];
function kamus(){var q=document.getElementById("cari").value.toLowerCase(),o="";K.forEach(function(x){if((x[0]+" "+x[1]).toLowerCase().indexOf(q)>-1)o+="<div class=gl><b>"+x[0]+"</b><br><span>"+x[1]+"</span></div>"});document.getElementById("kamus").innerHTML=o||"<p class=mut>Istilah tidak ditemukan.</p>"}kamus();
</script>

</details>
<div class=card><small><b>Sumber konsep:</b> Dokumentasi Apache HTTP Server (<a href="https://httpd.apache.org/docs/2.4/" target=_blank rel=noopener>httpd.apache.org/docs/2.4</a>) dan MDN, Gambaran Umum HTTP (<a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview" target=_blank rel=noopener>developer.mozilla.org</a>). Cerita, tokoh, gambar, dan data pada Pojok Digital ini adalah ilustrasi dan simulasi buatan untuk pembelajaran, bukan kisah atau data nyata.</small></div>
<script>
var cur=0,ST=document.querySelectorAll(".stp"),TB=document.querySelectorAll(".sb");
function go(i){cur=Math.max(0,Math.min(ST.length-1,i));ST.forEach(function(e,k){e.classList.toggle("on",k==cur)});TB.forEach(function(b,k){b.className="sb"+(k==cur?" on":"")+(k<cur?" done":"")});document.getElementById("kb").style.visibility=cur?"visible":"hidden";document.getElementById("lj").style.display=cur==ST.length-1?"none":"inline-block";window.scrollTo({top:0,behavior:"smooth"})}
go(0);
</script>
<?php }
?></main></div>
<script>function pres(){let on=document.body.classList.toggle("pres");try{localStorage.pres=on?1:0}catch(e){}if(on&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(function(){});if(!on&&document.fullscreenElement)document.exitFullscreen()}try{if(localStorage.pres==1)document.body.classList.add("pres")}catch(e){}</script>
